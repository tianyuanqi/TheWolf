"""固定r1源码与补证材料；不暂存、不提交，不覆盖r0。"""
from pathlib import Path
import hashlib,json,stat,zipfile
REPO=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf')
ROOT=Path('/private/tmp/thewolf-m01-r1-6psh4p0j')
ART=REPO/'docs/test-reports/artifacts'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old_path=ART/'TASK-20261005-01-r0-manifest.json'
old=json.loads(old_path.read_text());new=json.loads(old_path.read_text())
new['round']='r1';new['previous_snapshot']='TASK-20261005-01+r0+'+digest(old_path)
new['supplement_scope']='首次送审前补证；业务/测试源码无r1差异，status仅由协调者更新，追加r0报告依赖'
changes=[]
for item in new['files']:
 p=REPO/item['path'];h=digest(p);item['r0_sha256']=item['sha256'];item['change_from_r0']='unchanged' if h==item['sha256'] else 'modified-by-coordinator'
 if h!=item['sha256']:changes.append(item['path'])
 item.update(sha256=h,bytes=p.stat().st_size,mode=oct(stat.S_IMODE(p.stat().st_mode)))
assert changes==['docs/status.md'],changes
rel='docs/test-reports/TASK-20261005-01-implementation.md';p=REPO/rel
new['files'].append({'path':rel,'sha256':digest(p),'bytes':p.stat().st_size,'mode':oct(stat.S_IMODE(p.stat().st_mode)),'role':'r0-historical-report-read-only','change_from_r0':'added-as-dependency','baseline_sha256':None})
manifest=ART/'TASK-20261005-01-r1-manifest.json';assert not manifest.exists();manifest.write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n')
source=ART/'TASK-20261005-01-r1-source.zip';assert not source.exists()
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
 for item in new['files']:
  p=REPO/item['path'];info=zipfile.ZipInfo('workspace/'+item['path']);info.external_attr=(stat.S_IFREG|int(item['mode'],8))<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,p.read_bytes())
checks=[]
with zipfile.ZipFile(source) as z:
 for item in new['files']:
  name='workspace/'+item['path'];info=z.getinfo(name);assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256']==digest(REPO/item['path']);assert stat.S_IMODE(info.external_attr>>16)==int(item['mode'],8);checks.append(item['path'])
result={'files':len(checks),'all_hashes_modes_match':True,'r0_to_r1_business_source_changes':[],'r0_to_r1_dependency_changes':changes,'manifest_sha256':digest(manifest),'source_sha256':digest(source)}
(ROOT/'evidence/snapshot-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
