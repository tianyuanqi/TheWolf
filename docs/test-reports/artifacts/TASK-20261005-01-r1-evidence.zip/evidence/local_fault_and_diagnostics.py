"""本轮隔离验证专用：真实出站只观察错误；原生故障模式严格不触发POST。"""
import os,sys,json,time,traceback,re
from pathlib import Path
ROOT=Path('/private/tmp/thewolf-m01-r1-6psh4p0j')
if '--source' in sys.argv and os.environ.get('WOLF_QA_DIAGNOSTICS')=='1':
    import requests
    from urllib.parse import urlsplit,unquote
    original_get=requests.get
    secrets=[]
    for key,value in os.environ.items():
        if key=='WOLF_SESSION_TOKEN':secrets.append(value)
        if key.lower().endswith('_proxy'):
            parsed=urlsplit(value)
            secrets.extend([p for p in (parsed.username,parsed.password) if p])
            secrets.extend(unquote(p) for p in (parsed.username,parsed.password) if p)
    def clean(value):
        text=str(value)
        for secret in secrets:
            if secret:text=text.replace(secret,'[REDACTED]')
        text=re.sub(r'(https?://)[^\s/]+@',r'\1[REDACTED]@',text)
        return text[:1800]
    def observed_get(*args,**kwargs):
        try:return original_get(*args,**kwargs)
        except BaseException as error:
            pending=[error];seen=set();nodes=[]
            while pending and len(nodes)<12:
                node=pending.pop(0)
                if id(node) in seen:continue
                seen.add(id(node));nodes.append({'type':type(node).__module__+'.'+type(node).__name__,'message':clean(node),'errno':getattr(node,'errno',None)})
                pending.extend(p for p in (node.__cause__,node.__context__,getattr(node,'reason',None),*node.args) if isinstance(p,BaseException))
            with (ROOT/'evidence/live-diagnostics.jsonl').open('a') as stream:stream.write(json.dumps({'source':sys.argv[sys.argv.index('--source')+1],'time':time.time(),'chain':nodes})+'\n')
            raise
    requests.get=observed_get
elif os.environ.get('WOLF_QA_LOCAL_FAULTS')=='1':
    import asyncio
    import pmi.api as api
    from starlette.requests import Request
    original_app=api.app
    def log(event,**fields):
        with (ROOT/'evidence/local-ui-events.jsonl').open('a') as stream:stream.write(json.dumps({'event':event,'time':time.time(),**fields})+'\n')
    async def app(scope,receive,send):
        if scope['type']!='http':return await original_app(scope,receive,send)
        path=scope.get('path','');method=scope.get('method','');mode=json.loads((ROOT/'fault-mode.json').read_text());log('request',path=path,method=method)
        if method=='POST' and path in ('/api/indices/000300/update','/api/slice/update'):
            request=Request(scope)
            try:api._authorized(request,request.headers.get('x-wolf-session'))
            except Exception:return await original_app(scope,receive,send)
            delay=mode.get('post_delay',12);log('post_not_forwarded',path=path,delay=delay)
            await asyncio.sleep(delay)
            body=json.dumps({'stage':'idle','enabled':True,'job_id':None}).encode()
            await send({'type':'http.response.start','status':200,'headers':[(b'content-type',b'application/json')]})
            await send({'type':'http.response.body','body':body});return
        delay=mode.get('index_delay',0) if path=='/api/indices/000300' else mode.get('evidence_delay',0) if '/evidence/' in path else mode.get('pdf_delay',0) if '/pdf/' in path else 0
        async def delayed_send(message):
            if message['type']=='http.response.start' and delay:
                log('response_ready',path=path,delay=delay,status=message['status']);await asyncio.sleep(delay);log('response_sent',path=path,status=message['status'])
            await send(message)
        await original_app(scope,receive,delayed_send)
    api.app=app
