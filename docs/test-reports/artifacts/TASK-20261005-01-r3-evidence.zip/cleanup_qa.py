"""仅停止确属本轮端口的Vite并恢复基线不存在的QA应用缓存。"""
import subprocess,json,os,signal,time,shutil
from pathlib import Path
r=Path(__file__).resolve().parents[1]
vites=[]
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
    parts=line.strip().split(None,2)
    if len(parts)==3 and '/node_modules/.bin/vite ' in parts[2] and '--port 5174 --strictPort' in parts[2]:
        vites.append({'pid':int(parts[0]),'parent':int(parts[1]),'command':parts[2]})
for entry in vites:os.kill(entry['pid'],signal.SIGTERM)
time.sleep(.5)
owned=[]
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
    parts=line.strip().split(None,2)
    if len(parts)<3 or int(parts[0])==os.getpid():continue
    command=parts[2]
    if 'cleanup_qa.py' in command:continue
    if str(r) in command or ('-m uvicorn pmi.api:app' in command and '--port 8001' in command) or '-m pmi.index_fetch --source' in command:owned.append({'pid':parts[0],'command':command})
assert not owned,owned
(r/'evidence/process-cleanup.json').write_text(json.dumps({'stopped_vite':vites,'remaining_owned_processes':owned,'fetch_children_zero':True},indent=2))
before=json.loads((r/'evidence/app-state-before.json').read_text());stamp=(r/'evidence/app-state-before.json').stat().st_mtime
removed=[]
for name,existed in before.items():
    p=Path(name)
    if p.exists():
        assert not existed and p.stat().st_birthtime>=stamp-2,str(p)
        if p.is_dir():shutil.rmtree(p)
        else:p.unlink()
        removed.append(name)
assert all(Path(name).exists()==old for name,old in before.items())
(r/'evidence/app-state-restoration.json').write_text(json.dumps({'removed':removed,'all_absent_as_baseline':True,'created_after_baseline':True,'second_cleanup_after_narrow_check':True},indent=2))
shutil.rmtree(r/'TheWolf-QA.app')
print({'stopped_vite':len(vites),'remaining_owned_processes':len(owned),'app_state_restored':True})
