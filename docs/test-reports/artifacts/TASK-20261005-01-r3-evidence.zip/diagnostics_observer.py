"""本轮隔离验证专用：真实出站只观察错误；原生故障模式严格不触发POST。"""
import os,sys,json,time,traceback,re
from pathlib import Path
ROOT=Path('/private/tmp/thewolf-m01-r3-35isbawr')
if '--source' in sys.argv and os.environ.get('WOLF_QA_DIAGNOSTICS')=='1':
    import requests
    from urllib.parse import urlsplit,unquote
    original_get=requests.get
    secrets=[]
    for key,value in os.environ.items():
        if key=='WOLF_SESSION_TOKEN':secrets.append(value)
        if key.lower().endswith('_proxy'):
            parsed=urlsplit(value)
            secrets.extend([p for p in (parsed.username,parsed.password) if p])
            secrets.extend(unquote(p) for p in (parsed.username,parsed.password) if p)
    def clean(value):
        text=str(value)
        for secret in secrets:
            if secret:text=text.replace(secret,'[REDACTED]')
        text=re.sub(r'(https?://)[^\s/]+@',r'\1[REDACTED]@',text)
        return text[:1800]
    def observed_get(*args,**kwargs):
        try:return original_get(*args,**kwargs)
        except BaseException as error:
            pending=[error];seen=set();nodes=[]
            while pending and len(nodes)<12:
                node=pending.pop(0)
                if id(node) in seen:continue
                seen.add(id(node));nodes.append({'type':type(node).__module__+'.'+type(node).__name__,'message':clean(node),'errno':getattr(node,'errno',None)})
                pending.extend(p for p in (node.__cause__,node.__context__,getattr(node,'reason',None),*node.args) if isinstance(p,BaseException))
            with (ROOT/'evidence/live-diagnostics.jsonl').open('a') as stream:stream.write(json.dumps({'source':sys.argv[sys.argv.index('--source')+1],'time':time.time(),'chain':nodes,'traceback':clean(''.join(traceback.format_exception(error)))})+'\n')
            raise
    requests.get=observed_get
