"""只读取获准隔离原件，核验新发布与真实旧快照；不执行任何出站。"""
import json,shutil,socket,sqlite3
from pathlib import Path
from pmi.index_contract import Original,build_manifest,digest,parse_source
from pmi.index_snapshot import read_snapshot,read_evidence,index_root,publish
from pmi.writer_lock import writer_lock
ROOT=Path(__file__).resolve().parents[1]
def denied(*args,**kwargs):
    raise AssertionError('离线核验禁止网络')
socket.socket=denied
live=ROOT/'live-empty'
view=read_snapshot(live)
assert view['snapshot_id']=='f5719eae30f38546cef755634ec147c00e2f01a6f4b505b5cb7209478920ce09'
assert len(view['bars'])==260 and view['summary']['close']=='4357.62' and view['summary']['daily_change_pct']=='0.29'
evidences=[read_evidence(live,view['snapshot_id'],e['object_id']) for e in view['evidence']]
assert [e['source'] for e in evidences]==['tencent','csindex']
for l,r in zip(*(e['rows'] for e in evidences)):
    assert l['trade_date']==r['trade_date']
    assert all(l[f]==r[f] for f in ('open','high','low','close'))
raw=index_root(live)/'objects'/evidences[0]['object_id']
rows=parse_source('tencent',raw.read_bytes())
assert len(rows)==640 and rows[380].trade_date==view['window']['start'] and rows[-1].trade_date==view['window']['end']
representatives=[]
for day in ('2025-09-04','2025-12-31','2026-01-05','2026-09-30'):
    representatives.append({'date':day,'sources':[next(r for r in e['rows'] if r['trade_date']==day) for e in evidences]})
legacy_source=Path('/private/tmp/thewolf-m01-implementation-3kyht073/replay-final')
legacy=ROOT/'compat-real'
shutil.copytree(legacy_source,legacy)
old_id='4cb4a6ad0be6b869c70d2ca1dcd9f7a950e06fedff22ca0b0f9f3e32ec5ea220'
old=read_snapshot(legacy,old_id)
old_evidences=[read_evidence(legacy,old_id,e['object_id']) for e in old['evidence']]
old_hashes={p.relative_to(legacy_source).as_posix():digest(p.read_bytes()) for p in legacy_source.rglob('*') if p.is_file()}
new_inputs=tuple(Original(e['source'],(index_root(live)/'objects'/e['object_id']).read_bytes(),e['retrieval']['started_at'],e['retrieval']['completed_at']) for e in evidences)
with writer_lock(legacy):
    new_id=publish(legacy,build_manifest(tuple(view['calendar_dates']),new_inputs),new_inputs,{'job_id':'offline-compat-new','result':'business_changed'})
assert new_id==view['snapshot_id'] and read_snapshot(legacy)['snapshot_id']==new_id
assert read_snapshot(legacy,old_id)==old
assert [read_evidence(legacy,old_id,e['object_id']) for e in old['evidence']]==old_evidences
for name,sha in old_hashes.items():
    assert digest((legacy_source/name).read_bytes())==sha
    if '/objects/' in name:assert digest((legacy/name).read_bytes())==sha
with sqlite3.connect(index_root(live).joinpath('index.sqlite').as_uri()+'?mode=ro',uri=True) as db:
    assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    counts={t:db.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in ('snapshots','observations','current_snapshot','committed_jobs')}
ledger_path=Path('/private/tmp/thewolf-m01-implementation-3kyht073/evidence/network-ledger.jsonl')
ledger=ledger_path.read_bytes()
assert ledger.startswith((ROOT/'evidence/network-ledger-before.jsonl').read_bytes())
assert ledger==(ROOT/'evidence/network-ledger-before-offline.jsonl').read_bytes()
entries=[json.loads(s) for s in ledger.splitlines()];attempts=[e for e in entries if e['event']=='attempt'];finished=[e for e in entries if e['event']=='finished']
budget={'jobs':len({e['job_id'] for e in attempts}),'attempts':len(attempts),'bytes':sum(e['bytes'] for e in finished),'remaining_jobs':1,'remaining_attempts':4,'remaining_bytes':64*1024*1024-sum(e['bytes'] for e in finished),'last_job_reserved_for_review':True,'history_preserved':True,'offline_restart_no_source_requests':True}
assert budget['jobs']==7 and budget['attempts']==8 and budget['bytes']==158887
(ROOT/'evidence/network-budget.json').write_text(json.dumps(budget,indent=2))
(ROOT/'evidence/network-ledger.jsonl').write_bytes(ledger)
(ROOT/'evidence/live-job7-status.json').write_bytes(index_root(live).joinpath('update-status.json').read_bytes())
(ROOT/'evidence/live-original-observations.jsonl').write_bytes(index_root(live).joinpath('original-observations.jsonl').read_bytes())
result={'result':'PASS','snapshot_id':new_id,'observation_id':view['observation_id'],'source_contract':view['source_contract'],'days':260,'exact_ohlc_matches':1040,'tencent_raw_rows':640,'excluded_earlier_rows':380,'first_original_index':380,'last_original_index':639,'raw_bytes':len(raw.read_bytes()),'raw_sha256':digest(raw.read_bytes()),'sqlite_counts':counts,'legacy_snapshot_id':old_id,'legacy_source_root_unchanged':True,'legacy_view_evidence_objects_unchanged_after_new_publish':True,'representatives':representatives,'receipts':[{'source':e['source'],'object_id':e['object_id'],'retrieval':e['retrieval']} for e in evidences],'network_denied_during_check':True}
(ROOT/'evidence/real-saved-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ('representatives','source_contract','receipts')},ensure_ascii=False))
