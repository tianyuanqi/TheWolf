"""固定所测源码、规则及只读协调依赖，保存r2及真实HEAD差异；不创建Git提交。"""
import copy,difflib,hashlib,json,stat,subprocess,zipfile
from pathlib import Path
ROOT=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf');E=Path(__file__).parent;A=ROOT/'docs/test-reports/artifacts'
h=lambda b:hashlib.sha256(b).hexdigest()
old_path=A/'TASK-20261005-01-r2-manifest.json';old=json.loads(old_path.read_bytes());old_items={x['path']:x for x in old['files']}
extra=['python/tests/test_index_tencent.py','docs/test-reports/PLAN-P01-20261006-sina-precision.md','docs/test-reports/PLAN-P01-20261006-tencent-precision.md','docs/test-reports/TASK-20261005-01-r2-supplement.md']
files=[];patch=[];head_patch=[]
with zipfile.ZipFile(A/'TASK-20261005-01-r2-source.zip') as previous:
    assert previous.testzip() is None
    for name in sorted(set(old_items)|set(extra)):
        p=ROOT/name;content=p.read_bytes();sha=h(content);item=copy.deepcopy(old_items.get(name,{'path':name,'baseline_sha256':None,'change_from_task_start':'added','role':'task-implementation' if name.startswith('python/') else 'dependency-read-only'}))
        before=previous.read('workspace/'+name) if name in old_items else b''
        if name in old_items:assert h(before)==old_items[name]['sha256']
        item.update(sha256=sha,bytes=len(content),mode=oct(stat.S_IMODE(p.stat().st_mode)),r2_sha256=old_items.get(name,{}).get('sha256'),change_from_r2='unchanged' if before==content else ('modified-in-r3' if name in old_items else 'added-in-r3'))
        if name in ('docs/status.md','docs/tasks/TASK-20261005-01-csi300-price-slice.md','docs/Market-Dashboard-Design-V0.1.md','docs/Data-Sources-V0.1.md'):item['role']='coordinator-dependency-read-only'
        files.append(item)
        if before!=content:patch.extend(difflib.unified_diff(before.decode().splitlines(True),content.decode().splitlines(True),fromfile='r2/'+name if before else '/dev/null',tofile='r3/'+name))
        if item['role']=='task-implementation' or name=='README.md':
            git=subprocess.run(['git','show',old['baseline_git_sha']+':'+name],cwd=ROOT,capture_output=True)
            baseline=git.stdout if git.returncode==0 else b''
            if baseline!=content:head_patch.extend(difflib.unified_diff(baseline.decode().splitlines(True),content.decode().splitlines(True),fromfile='HEAD/'+name if baseline else '/dev/null',tofile='r3/'+name))
manifest={**old,'round':'r3','previous_snapshot':'TASK-20261005-01+r2+'+h(old_path.read_bytes()),'files':files,'supplement_scope':'Tencent primary with CSIndex exact verification, versioned read-only EastMoney archive compatibility, 8-job guard; no formal data or Git mutation','instructions':'Extract workspace into a new isolated directory, verify hashes/modes using verify_snapshot.py, use locked dependencies and README checks. Keep coordinator dependencies and existing planning changes separate. This fingerprint is not a Git commit.'}
manifest_data=json.dumps(manifest,ensure_ascii=False,indent=2).encode()+b'\n'
(A/'TASK-20261005-01-r3-manifest.json').write_bytes(manifest_data)
(A/'TASK-20261005-01-r2-to-r3.patch').write_text(''.join(patch))
(A/'TASK-20261005-01-head-to-r3-business.patch').write_text(''.join(head_patch))
with zipfile.ZipFile(A/'TASK-20261005-01-r3-source.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for item in files:
        info=zipfile.ZipInfo('workspace/'+item['path']);info.create_system=3;info.external_attr=(stat.S_IFREG|int(item['mode'],8))<<16;info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,(ROOT/item['path']).read_bytes())
    archive.writestr('manifest.json',manifest_data)
result={'snapshot':'TASK-20261005-01+r3+'+h(manifest_data),'source_files':len(files),'source_zip_sha256':h((A/'TASK-20261005-01-r3-source.zip').read_bytes()),'manifest_sha256':h(manifest_data),'changed_from_r2':[x['path'] for x in files if x['change_from_r2']!='unchanged'],'head_business_patch_sha256':h((A/'TASK-20261005-01-head-to-r3-business.patch').read_bytes()),'r2_patch_sha256':h((A/'TASK-20261005-01-r2-to-r3.patch').read_bytes())}
(E/'freeze-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
