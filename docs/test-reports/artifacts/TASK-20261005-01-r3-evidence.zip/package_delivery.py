"""归档脱敏日志/截图/重建脚本及固定文件哈希，报告自身不加入证据ZIP。"""
import hashlib,json,zipfile
from pathlib import Path
R=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf');E=Path(__file__).parent;A=R/'docs/test-reports/artifacts'
h=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(A/'TASK-20261005-01-r3-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(E.iterdir()):
        if p.is_file():z.write(p,p.name)
    assert z.testzip() is None
freeze=json.loads((E/'freeze-result.json').read_text());budget=json.loads((E/'network-budget.json').read_text())
paths=['docs/test-reports/TASK-20261005-01-r3-tencent.md',*[('docs/test-reports/artifacts/'+p) for p in ('TASK-20261005-01-r3-manifest.json','TASK-20261005-01-r3-source.zip','TASK-20261005-01-r3-evidence.zip','TASK-20261005-01-r2-to-r3.patch','TASK-20261005-01-head-to-r3-business.patch')]]
delivery={'task':'TASK-20261005-01','round':'r3','state':'ready-for-first-independent-review','baseline_sha':'ff614e4e2605292a9a151ea38a752677f10cd7e7','previous_snapshot':'TASK-20261005-01+r2+1b923bfc23521ad3eebc0d4213079075d85e99afb4a8e706c14780f7ec16ead0','fixed_snapshot':freeze['snapshot'],'files':[{'path':n,'sha256':h((R/n).read_bytes()),'bytes':(R/n).stat().st_size} for n in paths],'verification':{'backend_tests':57,'frontend_tests':39,'build':'PASS','loopback_api_parent_eof':'PASS','source_files':90,'real_job7':'PASS','raw_ohlc_exact_matches':1040,'native_representative_evidence':'PASS','offline_restart':'PASS','legacy_fixed_evidence_compatibility':'PASS','narrow_520x560':'PASS','restored':True,'vdoc':json.loads((E/'vdoc-result.json').read_text()) if (E/'vdoc-result.json').exists() else 'run before finalizing','no_commit':True,'no_status_write':True,'no_cross_thread_message':True,'independent_review':'not performed','user_acceptance':'not performed'},'real_budget':budget,'review_fix_rounds':'0/3','same_root_code_fix_failure_count':'0/2','runtime_model_verification':'not independently verified'}
(A/'TASK-20261005-01-r3-delivery.json').write_text(json.dumps(delivery,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source':freeze['snapshot'],'evidence_sha256':h((A/'TASK-20261005-01-r3-evidence.zip').read_bytes()),'report_sha256':h((R/paths[0]).read_bytes())}))
