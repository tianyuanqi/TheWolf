"""对照本轮开始指纹核验环境恢复，协调者维护的状态增量单列保留。"""
import json,os,hashlib,socket,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1];base=json.loads((r/'evidence/baseline.json').read_text());h=lambda data:hashlib.sha256(data).hexdigest()
ports={}
for p in base['ports']:
    with socket.socket() as s:s.settimeout(.2);ports[p]=s.connect_ex(('127.0.0.1',int(p)))==0
proxy={k:h(os.environ.get(k,'<UNSET>').encode()) for k in base['proxy_hashes']}
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();index=h(subprocess.check_output(['git','diff','--cached','--binary']))
changed=[name for name,sha in base['files'].items() if not Path(name).is_file() or h(Path(name).read_bytes())!=sha]
allowed={'README.md','apps/desktop/scripts/index_view.test.cjs','apps/desktop/src/MarketOverview.tsx','apps/desktop/src/indexTypes.ts','python/src/pmi/api.py','python/src/pmi/index_contract.py','python/src/pmi/index_fetch.py','python/src/pmi/index_snapshot.py','python/src/pmi/index_update.py','python/tests/index_replay_smoke.py','python/tests/test_index.py','docs/status.md'}
assert set(changed)<=allowed,changed
assert head==base['head'] and index==base['index_sha256'] and ports==base['ports'] and proxy==base['proxy_hashes']
assert not (r/'sitecustomize.py').exists() and not (r/'TheWolf-QA.app').exists()
assert all(not Path(p).exists() for p in json.loads((r/'evidence/app-state-before.json').read_text()))
result={'head':head,'head_index_unchanged':True,'ports':ports,'ports_restored':True,'proxy_environment_hashes_match_baseline':True,'changed_from_r3_start':changed,'external_state_document_change':'docs/status.md由协调者更新；coding只读，不覆盖','new_business_file':'python/tests/test_index_tencent.py','r0_r1_r2_reports_archives_unchanged':True,'observer_removed':True,'qa_bundle_removed':True,'app_state_restoration':'app-state-restoration.json','process_cleanup':'process-cleanup.json','formal_root':'never opened','isolated_data':'successful job7, replay and compatibility copies retained as inactive evidence only','remaining_impacts':[]}
(r/'evidence/restoration.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
