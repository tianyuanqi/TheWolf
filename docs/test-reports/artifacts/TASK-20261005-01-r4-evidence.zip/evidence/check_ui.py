"""核对已保存原生AX/本机API时序证据；不控制界面，不连接外部来源。"""
import json
from pathlib import Path
E=Path(__file__).parent
read=lambda n:(E/n).read_text()
events=[json.loads(x) for x in read('local-ui-events.jsonl').splitlines()]
pdfheld=next(x for x in events if x['event']=='pdf_body_held');pdfsent=next(x for x in events if x['event']=='pdf_body_sent')
market_between=[x for x in events if x['event']=='request' and x['path']=='/api/indices/000300' and pdfheld['time']<x['time']<pdfsent['time']]
eheld=[x for x in events if x['event']=='evidence_held'];esent=[x for x in events if x['event']=='evidence_sent']
legacy_between=[x for x in events if x['event']=='request' and x['path']=='/api/slice' and eheld[0]['time']<x['time']<esent[0]['time']]
posts=[x for x in events if x['event']=='request' and x['method']=='POST'];blocked=[x for x in events if x['event']=='post_not_forwarded']
assert market_between and legacy_between
assert '正在读取原件' in read('ui-pdf-body-pending-ax.txt')
assert not '本地归档原件' in read('ui-pdf-reentered-ax.txt')
assert not '本地归档原件' in read('ui-existing-pdf-reentered-ax.txt')
for doc in ['report','forecast']:
    assert '本地归档原件' in read(f'ui-{doc}-open-ax.txt')
    assert 'blob:http://127.0.0.1:5174/' in read(f'ui-{doc}-scroll-ax.txt')
    assert '本地归档原件' not in read(f'ui-{doc}-closed-ax.txt')
assert '读取固定原件' in read('ui-market-evidence-pending-ax.txt')
assert not '本地双源依据' in read('ui-market-evidence-reentered-ax.txt')
assert len(posts)==len(blocked)==1 and posts[0]['path']=='/api/slice/update'
assert '请求结果待核对' in read('ui-update-uncertain-ax.txt')
assert '更新结果待核对' in read('ui-update-deadline-ax.txt')
assert '未发现新的更新任务' in read('ui-update-resolved-ax.txt')
result={'result':'PASS','pdf_delay_seconds':pdfheld['delay'],'pdf_body_held_epoch':pdfheld['time'],'navigation_market_request_epoch':market_between[0]['time'],'pdf_body_sent_epoch':pdfsent['time'],'pdf_reentry_no_late_viewer':True,'existing_pdf_reentry_no_viewer':True,'real_report_and_forecast_read_close':True,'market_evidence_delay_seconds':eheld[0]['delay'],'evidence_held_epoch':eheld[0]['time'],'navigation_legacy_request_epoch':legacy_between[0]['time'],'evidence_sent_epoch':esent[0]['time'],'market_reentry_no_late_evidence':True,'local_update_posts':1,'posts_not_forwarded':1,'uncertain_deadline_manual_get_recovery':True,'financial_requests':0,'native_heap_measurement':'not performed; resource ownership established by deterministic real Blob URL tests'}
(E/'ui-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
