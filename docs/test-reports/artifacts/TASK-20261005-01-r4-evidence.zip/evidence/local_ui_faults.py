"""本轮本机QA专用：延迟PDF body/固定证据；全部POST不转发，禁止来源采集。"""
import os,json,time
from pathlib import Path
ROOT=Path('/private/tmp/thewolf-m01-r4-78g9r4un')
if os.environ.get('WOLF_R4_UI_FAULTS')=='1':
    import asyncio
    import pmi.api as api
    from starlette.requests import Request
    original_app=api.app
    def log(event,**fields):
        with (ROOT/'evidence/local-ui-events.jsonl').open('a') as stream:
            stream.write(json.dumps({'event':event,'time':time.time(),**fields})+'\n')
    async def app(scope,receive,send):
        if scope['type']!='http':return await original_app(scope,receive,send)
        path=scope.get('path','');method=scope.get('method','');mode=json.loads((ROOT/'fault-mode.json').read_text());log('request',path=path,method=method)
        if method=='POST':
            request=Request(scope)
            try:api._authorized(request,request.headers.get('x-wolf-session'))
            except Exception:return await original_app(scope,receive,send)
            log('post_not_forwarded',path=path)
            body=json.dumps({'detail':{'message':'明确合成：本机QA拒绝更新，不触发采集'}}).encode()
            await send({'type':'http.response.start','status':403,'headers':[(b'content-type',b'application/json')]})
            await send({'type':'http.response.body','body':body});return
        body_held=False
        async def delayed_send(message):
            nonlocal body_held
            if '/pdf/' in path and message['type']=='http.response.body' and not body_held and mode.get('pdf_body_delay',0):
                body_held=True;delay=mode['pdf_body_delay'];log('pdf_body_held',path=path,delay=delay)
                await asyncio.sleep(delay);log('pdf_body_sent',path=path)
            if '/evidence/' in path and message['type']=='http.response.start' and mode.get('evidence_delay',0):
                delay=mode['evidence_delay'];log('evidence_held',path=path,delay=delay)
                await asyncio.sleep(delay);log('evidence_sent',path=path)
            await send(message)
        await original_app(scope,receive,delayed_send)
    api.app=app
