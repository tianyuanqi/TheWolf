"""打包必要脱敏证据与固定交付索引；不包含真实库或金融原件。"""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf');E=Path(__file__).parent;A=ROOT/'docs/test-reports/artifacts'
h=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(A/'TASK-20261005-01-r4-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(E.iterdir()):
        if p.is_file():z.write(p,'evidence/'+p.name)
paths=['docs/test-reports/TASK-20261005-01-r4-pdf-unmount.md']+['docs/test-reports/artifacts/'+x for x in ['TASK-20261005-01-r4-manifest.json','TASK-20261005-01-r4-source.zip','TASK-20261005-01-r4-evidence.zip','TASK-20261005-01-r3-to-r4.patch','TASK-20261005-01-head-to-r4-business.patch']]
freeze=json.loads((E/'freeze-result.json').read_text())
result={'task_id':'TASK-20261005-01','round':'r4','stage':'R01 repair ready for independent re-review; not independently passed','baseline_git_sha':'ff614e4e2605292a9a151ea38a752677f10cd7e7','snapshot':freeze['snapshot'],'previous_snapshot':'TASK-20261005-01+r3+af091e94fb4d228f187391f968cc9609017dc17b723ed30c9382dc5ec586a279','review_report_sha256':'b864a2e39c10c83ac237de94bee8983dee65ddacf0d7e9ac44721ebcc1b699d5','review_round_on_handoff':1,'review_round_limit':3,'same_root_failed_repairs':0,'same_root_failed_repair_limit':2,'stop_triggered':False,'git':'not staged or committed; automatic fixed snapshot mode','model_requested':'gpt-6.1-sol/high','runtime_model':'not independently verified','coding_thread':'01a10a98-c976-75d1-9315-ec9a7af16235','reviewer_thread':'01a11071-2602-77f1-a45c-ba32ec471bbc','verification':{'v_fe':'43 passed','build':'passed','old_r3_reproduction':'reproduced; same new regression 3 pass and 2 expected fail','native_ui':'passed including both real PDFs and affected paths','restoration':'passed; no unrestored items','financial_source_requests':0,'ledger':'7 jobs / 8 attempts / 158887 bytes; final review job untouched'},'files':[{ 'path':n,'bytes':(ROOT/n).stat().st_size,'sha256':h((ROOT/n).read_bytes()) } for n in paths],'sending':'returned in coding window only; coordinator dispatches re-review'}
(A/'TASK-20261005-01-r4-delivery.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(paths),'snapshot':freeze['snapshot'],'evidence_sha256':h((A/'TASK-20261005-01-r4-evidence.zip').read_bytes())}))
