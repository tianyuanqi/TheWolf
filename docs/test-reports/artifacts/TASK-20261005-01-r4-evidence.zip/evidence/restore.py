"""仅恢复本轮隔离测试创建的进程引用、QA缓存与注入；保留业务成果和证据。"""
import hashlib,json,os,shutil,socket,subprocess,time
from pathlib import Path
ROOT=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf');T=Path('/private/tmp/thewolf-m01-r4-78g9r4un');E=T/'evidence'
h=lambda b:hashlib.sha256(b).hexdigest();baseline=json.loads((E/'baseline.json').read_text())
# 桌面先通过CUA退出，确保父EOF结束其服务；只处理本轮明确拥有的Vite。
proc=subprocess.run(['ps','-p','1774','-o','command='],capture_output=True,text=True).stdout.strip()
if proc:
    assert proc=='node /Users/yuanqi/Documents/ChatGPT/TheWolf/apps/desktop/node_modules/.bin/vite --host 127.0.0.1 --port 5174 --strictPort',proc
    os.kill(1774,15)
    time.sleep(1)
removed=[]
for name,existed in baseline['app_paths'].items():
    assert not existed
    p=Path(name)
    if p.exists():
        assert p.stat().st_birthtime>=(E/'baseline.json').stat().st_mtime-2,name
        if p.is_dir():shutil.rmtree(p)
        else:p.unlink()
        removed.append(name)
for name in ['sitecustomize.py','fault-mode.json','__pycache__','TheWolf-QA.app','repro-r3']:
    p=T/name
    if p.exists():
        if p.is_dir():shutil.rmtree(p)
        else:p.unlink()
ports={}
for port in baseline['ports']:
    with socket.socket() as s:
        s.settimeout(.2);ports[port]=s.connect_ex(('127.0.0.1',int(port)))==0
proxies={key:h(os.environ.get(key,'').encode()) for key in baseline['proxy_hashes']}
inputs=json.loads((E/'input-fingerprints.json').read_text());input_errors=[]
for base,files in inputs.items():
    actual={str(p.relative_to(base)):h(p.read_bytes()) for p in Path(base).rglob('*') if p.is_file()}
    if actual!=files:input_errors.append(base)
changed=[name for name,sha in baseline['files'].items() if not (ROOT/name).is_file() or h((ROOT/name).read_bytes())!=sha]
allowed={'README.md','apps/desktop/src/LegacySliceView.tsx','apps/desktop/scripts/evidence_read.test.mjs','docs/status.md'}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();index=h(subprocess.check_output(['git','diff','--cached','--binary'],cwd=ROOT))
ps=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True)
owned=[line for line in ps.splitlines() if ('TheWolf-QA.app/Contents/MacOS/thewolf-desktop' in line or '-m uvicorn pmi.api:app' in line or 'node /Users/yuanqi/Documents/ChatGPT/TheWolf/apps/desktop/node_modules/.bin/vite --host 127.0.0.1 --port 5174 --strictPort' in line or '-m pmi.index_fetch' in line)]
result={'ports':ports,'ports_match_baseline':ports==baseline['ports'],'proxy_hashes_match_baseline':proxies==baseline['proxy_hashes'],'head':head,'head_unchanged':head==baseline['head'],'index_unchanged':index==baseline['index_sha256'],'ledger_sha256':h(Path(baseline['ledger']).read_bytes()),'ledger_unchanged':h(Path(baseline['ledger']).read_bytes())==baseline['ledger_sha256'],'changed_baseline_files':changed,'only_authorized_changes':set(changed)<=allowed,'input_roots_unchanged':not input_errors,'input_errors':input_errors,'coordinator_status_delta':'read-only concurrent update retained; not restored', 'old_reports_and_artifacts_unchanged':all(h((ROOT/name).read_bytes())==sha for name,sha in baseline['files'].items() if name.startswith('docs/test-reports/')),'qa_paths_absent':all(not Path(n).exists() for n in baseline['app_paths']),'removed_qa_paths':removed,'active_injection_removed':not (T/'sitecustomize.py').exists() and not (T/'fault-mode.json').exists(),'owned_remaining_processes':owned,'formal_data':'not accessed','retained':'inactive ui-data test copy and evidence only','unrestored_items':[]}
assert all(result[k] for k in ['ports_match_baseline','proxy_hashes_match_baseline','head_unchanged','index_unchanged','ledger_unchanged','only_authorized_changes','input_roots_unchanged','old_reports_and_artifacts_unchanged','qa_paths_absent','active_injection_removed']),result
assert not owned,owned
(E/'restoration.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
