"""核对本次日常使用衔接的Markdown和原有状态历史。"""
from collections import Counter
from pathlib import Path
import json
import re
import subprocess
from urllib.parse import unquote

ROOT = Path('/Users/yuanqi/Documents/ChatGPT/TheWolf')
EVIDENCE = Path(__file__).parent
FILES = ['README.md', 'docs/status.md', 'docs/Market-Dashboard-Design-V0.1.md',
         'docs/tasks/TASK-20261005-01-csi300-price-slice.md',
         'docs/test-reports/TASK-20261005-01-r6-daily-enable.md',
         'docs/test-reports/TASK-20261005-01-review.md']

def content_lines(text):
    inside = False
    for line in text.splitlines():
        if line.lstrip().startswith('```'):
            inside = not inside
            continue
        if not inside:
            yield line
    assert not inside, '未闭合代码围栏'

def anchors(path):
    found = set()
    counts = Counter()
    for line in content_lines(path.read_text()):
        heading = re.match(r'^#{1,6}\s+(.+?)\s*#*$', line)
        if heading:
            label = re.sub(r'\[([^\]]+)\]\([^)]*\)', r'\1', heading[1])
            slug = re.sub(r'[^\w\- ]', '', label.lower()).replace(' ', '-')
            duplicate = counts[slug]
            found.add(slug if duplicate == 0 else f'{slug}-{duplicate}')
            counts[slug] += 1
    return found

links = 0
for name in FILES:
    path = ROOT / name
    text = path.read_text()
    assert all(line == line.rstrip() for line in text.splitlines()), f'{name}: 行尾空白'
    for line in content_lines(text):
        for reference in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)', line):
            reference = reference.strip('<>')
            if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', reference):
                continue
            target, _, fragment = reference.partition('#')
            dest = (path.parent / unquote(target)).resolve() if target else path
            assert dest.exists(), f'{name}: 文件缺失 {reference}'
            if fragment and dest.suffix == '.md':
                assert unquote(fragment) in anchors(dest), f'{name}: 锚点缺失 {reference}'
            links += 1
old = (EVIDENCE / 'status.md').read_text().split('## 历史记录\n', 1)[1]
current = (ROOT / 'docs/status.md').read_text().split('## 历史记录\n', 1)[1]
assert current.endswith(old), '原有状态历史被修改'
for args in (['git', 'diff', '--check'], ['git', 'diff', '--cached', '--check']):
    subprocess.run(args, cwd=ROOT, check=True)
result = {'result': 'passed', 'markdown_files': len(FILES), 'local_links_and_anchors': links,
          'fences': 'passed', 'trailing_space': 'passed', 'old_status_history': 'unchanged',
          'git_diff_check': 'passed', 'git_cached_diff_check': 'passed'}
(EVIDENCE / 'vdoc-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
print(json.dumps(result, ensure_ascii=False))
