"""只读核对自有日常服务的配置与接口，不输出会话凭据或触发采集。"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
from urllib.error import HTTPError
from urllib.request import Request, urlopen

parser = argparse.ArgumentParser()
parser.add_argument('--expected-enabled', type=int, choices=(0, 1), required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()
port = '8000'
pid = subprocess.check_output(['lsof', '-t', f'-iTCP:{port}', '-sTCP:LISTEN'], text=True).strip()
assert pid.isdecimal(), '日常服务监听不是单一进程'
# 捕获到的进程环境仅在内存中读取指定字段，不记录或输出原始文本。
process = subprocess.run(['ps', 'eww', '-p', pid, '-o', 'command='], capture_output=True, text=True, check=True)
def field(name):
    found = re.search(r'(?:^|\s)' + re.escape(name) + r'=([^\s]*)', process.stdout)
    return found[1] if found else None
token = field('WOLF_SESSION_TOKEN')
assert token, '无法读取本次自有桌面服务的会话身份'
root = field('WOLF_SLICE_DATA_ROOT')
expected_root = '/Users/yuanqi/Documents/ChatGPT/TheWolf/.local-data/slice-002245-sina'
assert root == expected_root, '日常服务数据根与约定不符'
assert field('WOLF_ENABLE_INDEX_UPDATE') == str(args.expected_enabled), '运行进程仍使用其他指数开关'
assert not field('WOLF_INDEX_BUDGET_LEDGER'), '日常服务继承了隔离验证账本'

def read(path):
    request = Request('http://127.0.0.1:8000' + path, headers={'X-Wolf-Session': token})
    try:
        with urlopen(request, timeout=5) as response:
            return response.status, json.load(response)
    except HTTPError as error:
        return error.code, json.load(error)

ready_code, ready = read('/api/session/ready')
assert ready_code == 200 and ready['status'] == 'ready'
update_code, update = read('/api/indices/000300/update')
assert update_code == 200 and update['enabled'] == bool(args.expected_enabled)
slice_code, legacy = read('/api/slice')
assert slice_code == 200
index_code, index = read('/api/indices/000300')
record = {'service_pid': int(pid), 'data_root': root, 'ready_status': ready_code,
          'index_enabled': update['enabled'], 'index_stage': update['stage'],
          'index_job_id': update.get('job_id'), 'index_read_status': index_code,
          'index_error_code': index.get('detail', {}).get('code') if index_code != 200 else None,
          'legacy_read_status': slice_code, 'legacy_snapshot_id': legacy['snapshot_id'],
          'test_ledger_override': False, 'method': 'authenticated local GET only',
          'native_ui_observed': False, 'user_acceptance': 'pending'}
Path(args.output).write_text(json.dumps(record, ensure_ascii=False, indent=2))
print(json.dumps(record, ensure_ascii=False))
