"""核对日常重启后的固定代码、旧数据与已授权保留状态。"""
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import zipfile

ROOT = Path('/Users/yuanqi/Documents/ChatGPT/TheWolf')
EVIDENCE = Path(__file__).parent
baseline = json.loads((EVIDENCE / 'baseline.json').read_text())
runtime_file = EVIDENCE / 'runtime-current.json'
runtime = json.loads((runtime_file if runtime_file.exists() else EVIDENCE / 'runtime-after.json').read_text())
assert runtime['index_enabled'] is True
assert runtime['legacy_read_status'] == 200
assert not runtime['test_ledger_override']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == baseline['head']
assert subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=ROOT, text=True) == baseline['index_diff']
allowed = {'README.md', 'apps/desktop/scripts/start_daily.mjs', 'apps/desktop/scripts/start_daily.test.mjs',
           'docs/status.md', 'docs/Market-Dashboard-Design-V0.1.md',
           'docs/tasks/TASK-20261005-01-csi300-price-slice.md',
           'docs/test-reports/TASK-20261005-01-review.md'}
changed = []
for name, item in baseline['files'].items():
    path = ROOT / name
    assert path.is_file(), f'原文件缺失 {name}'
    assert stat.S_IMODE(path.stat().st_mode) == item['mode'], f'文件模式变化 {name}'
    if hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
        assert name in allowed, f'出现范围外改动 {name}'
        changed.append(name)

manifest = json.loads((ROOT / 'docs/test-reports/artifacts/TASK-20261005-01-r6-manifest.json').read_text())
exceptions = {'docs/status.md', 'docs/test-reports/TASK-20261005-01-review.md'}
for item in manifest['files']:
    if item['path'] not in exceptions:
        assert hashlib.sha256((ROOT / item['path']).read_bytes()).hexdigest() == item['sha256'], item['path']
with zipfile.ZipFile(ROOT / 'docs/test-reports/artifacts/TASK-20261005-01-r6-source.zip') as archive:
    old_review = archive.read('workspace/docs/test-reports/TASK-20261005-01-review.md')
    assert (ROOT / 'docs/test-reports/TASK-20261005-01-review.md').read_bytes().startswith(old_review)

data_root = Path(baseline['data_root'])
legacy_hashes = {str(path.relative_to(data_root)): hashlib.sha256(path.read_bytes()).hexdigest()
                 for path in data_root.rglob('*') if path.is_file() and 'indices' not in path.relative_to(data_root).parts}
legacy_unchanged = legacy_hashes == baseline['legacy_data_files']
index_exists = (data_root / 'indices/csi000300').exists()
proxy_unchanged = all((hashlib.sha256(os.environ[key].encode()).hexdigest() if key in os.environ else None) == digest
                      for key, digest in baseline['proxy_hashes'].items())
assert proxy_unchanged, '代理环境变化'
result = {'result': 'passed' if legacy_unchanged else 'needs attribution; legacy data changed after handoff',
          'head': baseline['head'], 'index': 'unchanged and empty', 'changed_baseline_files': changed,
          'fixed_r6_source': 'matched excluding separately maintained status and appended review',
          'prior_review_prefix': 'unchanged', 'legacy_data_hashes_unchanged': legacy_unchanged,
          'legacy_file_count': len(legacy_hashes), 'index_directory_exists': index_exists,
          'proxy_environment': 'unchanged', 'service_pid': runtime['service_pid'],
          'index_enabled': True, 'index_stage': runtime['index_stage'], 'index_job_id': runtime['index_job_id'],
          'source_requests_by_coordinator': 0, 'native_ui_observation': 'unverified; tool cannot bind development app',
          'retained_environment': 'authorized daily window on 5173/8000 for user verification',
          'test_environment_left_running': False, 'user_acceptance': 'pending'}
(EVIDENCE / 'handoff-check.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
print(json.dumps(result, ensure_ascii=False))
