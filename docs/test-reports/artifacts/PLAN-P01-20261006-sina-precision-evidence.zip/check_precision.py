"""离线复核已保存沪深300原件；不联网、不修改原件或产品代码。"""
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP, ROUND_HALF_EVEN, ROUND_HALF_DOWN
from collections import Counter
import ast, hashlib, json, re, subprocess, socket, sys
from py_mini_racer import MiniRacer

ROOT=Path('/private/tmp/thewolf-p01-csi300-qkuqgt8q')
OUT=Path(__file__).resolve().parent
REPO=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf')
FIELDS=('open','high','low','close')
HASHES={'S01':'bd0ff8a9e8e09da9a8efa3cbbf3696a4dbecbad560147469e3bb53e74761db29','C01':'40aff181ee6a4503d73cca807ec7c67e7be733429136c59d4e7550b609ca9e43','E01':'846aa040400b173a179f359db4f4813646a4df17215fc7718ac440f2939e7282'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def deny_network(*args,**kwargs):
    raise RuntimeError('本离线检查禁止网络连接')

socket.create_connection=deny_network
socket.socket.connect=deny_network
socket.socket.connect_ex=deny_network
raw={k:(ROOT/'raw'/v).read_bytes() for k,v in HASHES.items()}
assert all(sha(raw[k])==v for k,v in HASHES.items())
calendar_path=ROOT/'evidence/calendar.json'
calendar=json.loads(calendar_path.read_bytes());days=calendar['expected_W260']
assert len(days)==260 and len(set(days))==260 and days==sorted(days)
cons=REPO/'python/.venv/lib/python3.12/site-packages/akshare/stock/cons.py'
decoder=None
for n in ast.parse(cons.read_text()).body:
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='hk_js_decode' for t in n.targets):decoder=ast.literal_eval(n.value)
assert decoder
match=re.fullmatch(r'var KLC_KL_sh000300="([^"]+)";?\s*(?:/\*[\s\S]*\*/)?\s*',raw['S01'].decode())
assert match
payload=match[1]
(OUT/'decoder.js').write_text(decoder)
(OUT/'payload.json').write_text(json.dumps(payload))

def decode_v8():
    engine=MiniRacer()
    try:
        engine.eval(decoder,timeout_sec=5,max_memory=64000000)
        # JS直接序列化再按Decimal解析，避免Python float成为对账中间值。
        text=engine.eval('JSON.stringify(d('+json.dumps(payload)+'))',timeout_sec=5,max_memory=64000000)
        return json.loads(text,parse_float=Decimal)
    finally:engine.close()

s1=decode_v8();s2=decode_v8();assert s1==s2
node_code="""const fs=require('fs'),vm=require('vm');const c=vm.createContext({});vm.runInContext(fs.readFileSync(process.argv[1],'utf8'),c,{timeout:5000});c.payload=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));process.stdout.write(vm.runInContext('JSON.stringify(d(payload))',c,{timeout:5000}));"""
node=subprocess.run(['node','--max-old-space-size=128','-e',node_code,str(OUT/'decoder.js'),str(OUT/'payload.json')],capture_output=True,text=True,timeout=15,check=True)
s3=json.loads(node.stdout,parse_float=Decimal);assert s1==s3
stored=json.loads((ROOT/'derived/sina-decoded.json').read_text(),parse_float=Decimal);assert s1==stored
s={}
for row in s1:
    day=row['date'][:10]
    assert day not in s
    s[day]={f:Decimal(row[f]) for f in FIELDS}
s={day:vals for day,vals in s.items() if days[0]<=day<=days[-1]}
c=json.loads(raw['C01'],parse_float=Decimal);assert c['success'] and c['code']=='200'
assert all(r['indexCode']=='000300' and r['indexNameCn']=='沪深300' for r in c['data'])
c={r['tradeDate'][:4]+'-'+r['tradeDate'][4:6]+'-'+r['tradeDate'][6:]:{f:Decimal(r[f]) for f in FIELDS} for r in c['data']}
e=json.loads(raw['E01']);assert e['data']['code']=='000300' and e['data']['market']==1 and e['data']['decimal']==2
erows=[x.split(',') for x in e['data']['klines']];e={a[0]:dict(zip(('open','close','high','low'),map(Decimal,a[1:5]))) for a in erows}
assert len(c)==len(e)==260
for source in (s,c,e):
    assert set(source)==set(days)
    for row in source.values():
        assert all(x.is_finite() and x>0 for x in row.values())
        assert row['low']<=row['open']<=row['high'] and row['low']<=row['close']<=row['high']
assert c==e
quantum=Decimal('.01');half=Decimal('.005');audit=[]
for day in days:
    for f in FIELDS:
        a,b=s[day][f],c[day][f]
        assert a*1000==(a*1000).to_integral_value()
        assert b*100==(b*100).to_integral_value()
        audit.append({'date':day,'field':f,'sina':str(a),'csi':str(b),'delta':str(a-b),'tie':a%quantum==half,'half_up':str(a.quantize(quantum,rounding=ROUND_HALF_UP)),'half_even':str(a.quantize(quantum,rounding=ROUND_HALF_EVEN)),'half_down':str(a.quantize(quantum,rounding=ROUND_HALF_DOWN))})
(OUT/'all-field-comparisons.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
ties=[r for r in audit if r['tie']];not_ties=[r for r in audit if not r['tie']]
summary={'source_hashes':HASHES,'source_bytes':{k:len(v) for k,v in raw.items()},'calendar_sha256':sha(calendar_path.read_bytes()),'decoder_sha256':sha(decoder.encode()),'cons_file_sha256':sha(cons.read_bytes()),'window':[days[0],days[-1]],'days':len(days),'fields':len(audit),'sina_decoded_total_rows':len(s1),'replay_checks':{'two_fresh_v8_contexts_equal':True,'node_same_decoder_equal':True,'existing_p01_decode_equal':True,'decimal_from_js_json':True,'external_requests':0},'structure_checks':{'complete_dates':True,'unique_dates':True,'valid_ohlc':True,'sina_values_on_0_001_grid':True,'csi_values_on_0_01_grid':True,'eastmoney_csi_exact_equal':True},'raw_exact':sum(Decimal(r['delta'])==0 for r in audit),'raw_differ':sum(Decimal(r['delta'])!=0 for r in audit),'max_abs_delta':str(max(abs(Decimal(r['delta'])) for r in audit)),'quantization_results':{},'ties':{'count':len(ties),'days':len({r['date'] for r in ties}),'csi_above':sum(Decimal(r['csi'])>Decimal(r['sina']) for r in ties),'csi_below':sum(Decimal(r['csi'])<Decimal(r['sina']) for r in ties),'by_field':dict(Counter(r['field'] for r in ties))},'non_ties':{'count':len(not_ties),'half_up_exact':sum(Decimal(r['half_up'])==Decimal(r['csi']) for r in not_ties)},'examples':ties[:8],'inference':'两源从更高精度分别舍入可解释边界混向，但原始更高精度值/来源规则未取得；不据拟合规则自动准入','audit_sha256':sha((OUT/'all-field-comparisons.json').read_bytes())}
for name in ('half_up','half_even','half_down'):
    bad=[r for r in audit if Decimal(r[name])!=Decimal(r['csi'])]
    summary['quantization_results'][name]={'equal':len(audit)-len(bad),'different':len(bad),'different_non_ties':sum(not r['tie'] for r in bad),'affected_days':len({r['date'] for r in bad})}
assert summary['raw_exact']==102 and summary['raw_differ']==938
assert summary['non_ties']['half_up_exact']==len(not_ties)
assert all(sha((ROOT/'raw'/v).read_bytes())==v for v in HASHES.values())
summary['raw_files_unchanged']=True
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
