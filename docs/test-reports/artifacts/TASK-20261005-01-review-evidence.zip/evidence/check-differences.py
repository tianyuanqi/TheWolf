from pathlib import Path
import json,zipfile,hashlib,subprocess,difflib
REPO=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf');ROOT=Path('/private/tmp/thewolf-m01-review-z10a_uih');A=REPO/'docs/test-reports/artifacts';h=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((A/'TASK-20261005-01-r3-manifest.json').read_text());m2=json.loads((A/'TASK-20261005-01-r2-manifest.json').read_text());patch=[];headpatch=[]
with zipfile.ZipFile(A/'TASK-20261005-01-r2-source.zip') as z:
 assert z.testzip() is None
 old={f['path']:z.read('workspace/'+f['path']) for f in m2['files']}
 for f in m2['files']:assert h(old[f['path']])==f['sha256']
changed=[];business=[]
for f in m['files']:
 name=f['path'];before=old.get(name,b'');content=(ROOT/'workspace'/name).read_bytes();assert h(content)==f['sha256']
 if f.get('r2_sha256') is not None:assert h(before)==f['r2_sha256']
 if before!=content:
  changed.append(name);patch.extend(difflib.unified_diff(before.decode().splitlines(True),content.decode().splitlines(True),fromfile='r2/'+name if before else '/dev/null',tofile='r3/'+name))
 if f['role']=='task-implementation' or name=='README.md':
  git=subprocess.run(['git','show',m['baseline_git_sha']+':'+name],capture_output=True,cwd=REPO);baseline=git.stdout if git.returncode==0 else b''
  if baseline!=content:business.append(name);headpatch.extend(difflib.unified_diff(baseline.decode().splitlines(True),content.decode().splitlines(True),fromfile='HEAD/'+name if baseline else '/dev/null',tofile='r3/'+name))
assert ''.join(patch).encode()==(A/'TASK-20261005-01-r2-to-r3.patch').read_bytes()
assert ''.join(headpatch).encode()==(A/'TASK-20261005-01-head-to-r3-business.patch').read_bytes()
(ROOT/'evidence/difference-check.json').write_text(json.dumps({'result':'PASS','r2_changed':changed,'head_business_and_readme_changed':business,'r2_hashes_verified':True,'both_patches_exactly_reconstructed':True},indent=2));print('both fixed patches exactly reconstructed; source hashes still match')
