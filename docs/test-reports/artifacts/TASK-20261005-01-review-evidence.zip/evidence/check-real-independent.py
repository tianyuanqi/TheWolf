from pathlib import Path
import json,hashlib,shutil,socket,sqlite3
from decimal import Decimal,ROUND_HALF_UP
from pmi.index_contract import Original,build_manifest,digest
from pmi.index_snapshot import read_snapshot,read_evidence,index_root,publish
from pmi.writer_lock import writer_lock
ROOT=Path('/private/tmp/thewolf-m01-review-z10a_uih')
LIVE=Path('/private/tmp/thewolf-m01-r3-35isbawr/live-empty')
OLD=Path('/private/tmp/thewolf-m01-implementation-3kyht073/replay-final')
def inventory(root):return {p.relative_to(root).as_posix():digest(p.read_bytes()) for p in root.rglob('*') if p.is_file()}
def denied(*args,**kwargs):raise AssertionError('independent offline verification forbids network')
socket.socket=denied
before={str(p):inventory(p) for p in (LIVE,OLD)}
for src,name in ((LIVE,'real-copy'),(OLD,'old-copy')):shutil.copytree(src,ROOT/name)
live=ROOT/'real-copy';old=ROOT/'old-copy'
v=read_snapshot(live)
assert v['snapshot_id']=='f5719eae30f38546cef755634ec147c00e2f01a6f4b505b5cb7209478920ce09'
es=[read_evidence(live,v['snapshot_id'],x['object_id']) for x in v['evidence']]
contents=[(index_root(live)/'objects'/x['object_id']).read_bytes() for x in es]
assert [digest(x) for x in contents]==['6242d8b6847926987d2e693a9fbb712fcbb39d6db76e7d801647e18593a89237','40aff181ee6a4503d73cca807ec7c67e7be733429136c59d4e7550b609ca9e43']
# 独立直接读取原字段，不调用生产适配器，确认映射和逐值支持关系。
txt=contents[0].decode();assert txt.startswith('kline_dayqfq=');t=json.loads(txt[len('kline_dayqfq='):].rstrip().rstrip(';'),parse_float=Decimal)['data']['sh000300']['day'];c=json.loads(contents[1],parse_float=Decimal)['data']
assert len(t)==640 and len(c)==260
selected=[(i,row) for i,row in enumerate(t) if v['window']['start']<=row[0]<=v['window']['end']]
assert len(selected)==260 and selected[0][0]==380 and selected[-1][0]==639
for n,((rawindex,a),b,bar) in enumerate(zip(selected,c,v['bars'])):
 assert a[0]==bar['trade_date']==f"{b['tradeDate'][:4]}-{b['tradeDate'][4:6]}-{b['tradeDate'][6:]}"
 for field,pos in [('open',1),('close',2),('high',3),('low',4)]:assert Decimal(a[pos])==Decimal(str(b[field]))==Decimal(bar[field])
 assert bar['evidence_refs'][0]['locator']==f'$.data.sh000300.day[{rawindex}]'
 assert bar['evidence_refs'][1]['locator']==f'$.data[{n}]'
pct=((Decimal(v['bars'][-1]['close'])/Decimal(v['bars'][-2]['close'])-1)*100).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
assert str(pct)==v['summary']['daily_change_pct']=='0.29'
oldid='4cb4a6ad0be6b869c70d2ca1dcd9f7a950e06fedff22ca0b0f9f3e32ec5ea220';ov=read_snapshot(old,oldid);oe=[read_evidence(old,oldid,x['object_id']) for x in ov['evidence']];oldobjects=inventory(index_root(old)/'objects')
assert ov['source_contract']['version']=='csi300-exact-ohlc-v1' and oe[0]['source']=='eastmoney'
items=tuple(Original(e['source'],content,e['retrieval']['started_at'],e['retrieval']['completed_at']) for e,content in zip(es,contents))
with writer_lock(old):newid=publish(old,build_manifest(tuple(v['calendar_dates']),items),items,{'job_id':'independent-compat','result':'evidence_changed'})
assert newid==v['snapshot_id'] and read_snapshot(old)['snapshot_id']==newid
assert read_snapshot(old,oldid)==ov and [read_evidence(old,oldid,x['object_id']) for x in ov['evidence']]==oe
assert all((index_root(old)/'objects'/p).is_file() and digest((index_root(old)/'objects'/p).read_bytes())==h for p,h in oldobjects.items())
for p in (LIVE,OLD):assert inventory(p)==before[str(p)]
ledger=Path('/private/tmp/thewolf-m01-implementation-3kyht073/evidence/network-ledger.jsonl');lines=[json.loads(x) for x in ledger.read_text().splitlines()];attempts=[x for x in lines if x['event']=='attempt'];finished=[x for x in lines if x['event']=='finished'];assert len({x['job_id'] for x in attempts})==7 and len(attempts)==8 and sum(x['bytes'] for x in finished)==158887
with sqlite3.connect((index_root(live)/'index.sqlite').as_uri()+'?mode=ro',uri=True) as db:assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert not db.execute('PRAGMA foreign_key_check').fetchall()
result={'result':'PASS','socket_network_denied':True,'snapshot_id':newid,'original_sizes':[len(x) for x in contents],'independent_exact_matches':1040,'raw_rows':640,'selected_indexes':[380,639],'daily_change_pct':str(pct),'legacy_snapshot_and_evidence_unchanged':True,'input_directories_unchanged':True,'input_inventory':before,'budget':{'jobs':7,'attempts':8,'bytes':158887,'review_job_consumed':False}}
(ROOT/'evidence/real-independent.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='input_inventory'},ensure_ascii=False))
