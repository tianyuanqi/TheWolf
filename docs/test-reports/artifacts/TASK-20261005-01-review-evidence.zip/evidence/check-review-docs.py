from pathlib import Path
import json,re,subprocess,unicodedata
from urllib.parse import unquote
REPO=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf');ROOT=Path('/private/tmp/thewolf-m01-review-z10a_uih');p=REPO/'docs/test-reports/TASK-20261005-01-review.md';text=p.read_text();errors=[];links=[]
for target in re.findall(r'(?<!!)\[[^\]]+\]\(([^)]+)\)',text):
 if re.match(r'^[a-z]+:',target):continue
 location,_,anchor=unquote(target).partition('#');dest=(p.parent/location).resolve() if location else p
 if not dest.exists():errors.append('missing '+target)
 elif anchor:
  headings=re.findall(r'^#{1,6}\s+(.+)$',dest.read_text(),re.M)
  slug=lambda s:re.sub(r'[^\w\-\s]','',s.lower()).replace(' ','-')
  if anchor not in map(slug,headings):errors.append('missing anchor '+target)
 links.append(target)
assert sum(1 for line in text.splitlines() if line.startswith('```'))%2==0
assert not any(line.rstrip()!=line for line in text.splitlines())
for command in (['git','diff','--check'],['git','diff','--cached','--check']):
 result=subprocess.run(command,cwd=REPO,capture_output=True,text=True)
 if result.returncode:errors.append(result.stdout+result.stderr)
r={'result':'PASS' if not errors else 'FAIL','markdown_files':1,'local_links':len(links),'errors':errors};(ROOT/'evidence/vdoc-result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False));assert not errors
