from pathlib import Path
import json,hashlib,subprocess,os,shutil
ROOT=Path('/private/tmp/thewolf-m01-review-z10a_uih');REPO=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf');b=json.loads((ROOT/'evidence/baseline.json').read_text());h=lambda x:hashlib.sha256(x).hexdigest()
def run(*args):return subprocess.run(args,capture_output=True,text=True,cwd=REPO).stdout
# 仅清理本审查隔离副本生成的运行产物/数据及外部依赖引用。
removed=[]
for relative in ['workspace/apps/desktop/node_modules','workspace/apps/desktop/dist','workspace/apps/desktop/tsconfig.tsbuildinfo','workspace/apps/desktop/tsconfig.node.tsbuildinfo','real-copy','old-copy']:
 p=ROOT/relative
 if p.is_symlink():p.unlink();removed.append(relative)
 elif p.is_dir():shutil.rmtree(p);removed.append(relative)
 elif p.is_file():p.unlink();removed.append(relative)
for p in (ROOT/'workspace').rglob('__pycache__'):
 if p.is_dir():shutil.rmtree(p);removed.append(str(p.relative_to(ROOT)))
changed=[p for p,sha in b['files'].items() if not (REPO/p).is_file() or h((REPO/p).read_bytes())!=sha]
head=run('git','rev-parse','HEAD').strip();index=h(run('git','ls-files','--stage').encode());assert head==b['head'] and index==b['index']
assert set(changed)<= {'docs/status.md'},changed
proxy={k:h(os.environ[k].encode()) if k in os.environ else None for k in b['environment']};assert proxy==b['environment']
ledger=Path('/private/tmp/thewolf-m01-implementation-3kyht073/evidence/network-ledger.jsonl');assert h(ledger.read_bytes())==b['ledger_sha256']
processes=run('ps','-axo','pid,ppid,command');listeners=run('lsof','-nP','-iTCP','-sTCP:LISTEN')
# ps会包含本恢复脚本，不把短期检查者当残留服务。
residual=[line for line in processes.splitlines() if str(ROOT) in line and any(s in line for s in ['uvicorn','index_fetch','vite','thewolf-desktop'])];assert not residual,residual
ports={port:any(':'+str(port)+' ' in line for line in listeners.splitlines()) for port in [5173,8000,5174,8001,5184,8014]};assert not any(ports.values()),ports
result={'result':'PASS','head':head,'index_unchanged':True,'existing_files_changed':changed,'proxy_root_switch_environment_unchanged':True,'source_ledger_unchanged':True,'review_source_requests':0,'review_job_consumed':False,'residual_task_processes':residual,'related_ports_listening':ports,'baseline_related_ports':{port:any(':'+str(port)+' ' in line for line in b['listeners'].splitlines()) for port in ports},'removed_own_isolated_artifacts':removed,'app_state':'No native app or browser launched; no app caches/preferences/windows modified.','retained':'Fixed isolated source and evidence/scripts; no live service/data-root/dependency pointer remains.','unrestored_items':[]}
(ROOT/'evidence/restoration.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='removed_own_isolated_artifacts'},ensure_ascii=False))
