from pathlib import Path
import hashlib, json, stat, subprocess, zipfile

REPO = Path('/Users/yuanqi/Documents/ChatGPT/TheWolf')
ROOT = Path('/private/tmp/thewolf-m01-r4-review-vv_8tefy')
E = ROOT/'evidence'
A = REPO/'docs/test-reports/artifacts'
REPORT = REPO/'docs/test-reports/TASK-20261005-01-review.md'
ZIP = A/'TASK-20261005-01-review-r1-evidence.zip'
INDEX = A/'TASK-20261005-01-review-r1-delivery.json'
h = lambda b: hashlib.sha256(b).hexdigest()

def package():
    files = [p for p in sorted(E.iterdir()) if p.is_file() and p.name != 'archive-manifest.json']
    manifest = {'task':'TASK-20261005-01', 'review_round':1,
                'files':[{'path':'evidence/'+p.name, 'sha256':h(p.read_bytes()),
                          'bytes':p.stat().st_size, 'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
                         for p in files]}
    (E/'archive-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in files+[E/'archive-manifest.json']:
            z.write(p,'evidence/'+p.name)
    with zipfile.ZipFile(ZIP) as z:
        assert z.testzip() is None
        assert set(z.namelist()) == {f['path'] for f in manifest['files']} | {'evidence/archive-manifest.json'}
        for f in manifest['files']:
            content = z.read(f['path'])
            assert h(content) == f['sha256'] and len(content) == f['bytes']
            assert stat.S_IMODE(z.getinfo(f['path']).external_attr>>16) == int(f['mode'],8)
    return manifest

# Create the two concrete targets before checking report links; final hashes follow QA.
package()
INDEX.write_text(json.dumps({'task':'TASK-20261005-01','review_round':1,'state':'assembling'})+'\n')
subprocess.run(['python3',str(E/'check-review-docs.py')],cwd=REPO,check=True)
manifest = package()
b = json.loads((E/'baseline.json').read_text())
before = (E/'review-before.md').read_bytes()
assert REPORT.read_bytes().startswith(before)
assert h(before) == 'b864a2e39c10c83ac237de94bee8983dee65ddacf0d7e9ac44721ebcc1b699d5'
def git(*args):
    result = subprocess.run(['git',*args],cwd=REPO,capture_output=True,text=True,check=True)
    return result.stdout
assert git('rev-parse','HEAD').strip() == b['head']
assert h(git('ls-files','--stage').encode()) == b['index_sha256']
changed = [p for p,sha in b['files'].items()
           if not (REPO/p).is_file() or h((REPO/p).read_bytes()) != sha]
assert changed == ['docs/test-reports/TASK-20261005-01-review.md'], changed
current = set(git('ls-files').splitlines()) | set(git('ls-files','--others','--exclude-standard').splitlines())
added = sorted(current-set(b['files']))
assert added == sorted([str(ZIP.relative_to(REPO)),str(INDEX.relative_to(REPO))]), added
restoration = json.loads((E/'restoration.json').read_text())
vdoc = json.loads((E/'vdoc-result.json').read_text())
assert restoration['result'] == vdoc['result'] == 'PASS'
idx = {
 'task':'TASK-20261005-01', 'review_round':1, 'review_thread':'01a11071-2602-77f1-a45c-ba32ec471bbc',
 'baseline_sha':b['head'],
 'previous_reviewed_snapshot':'TASK-20261005-01+r3+af091e94fb4d228f187391f968cc9609017dc17b723ed30c9382dc5ec586a279',
 'fixed_snapshot':'TASK-20261005-01+r4+51a7ed70004a63f2a3e1fab60c4933e507879503892c2b96575139435ceebe7d',
 'conclusion':'needs_changes',
 'findings':[{'id':'M01-R01','classification':'confirmed-defect','severity':'P2','state':'unresolved',
              'origin':'same incomplete PDF object URL ownership, accepted state update not committed before navigation unmount',
              'new_id':False}],
 'counters_for_coordinator':{'review_round':1,'review_limit':3,'same_root_failure_before':0,
                            'recommended_same_root_failure_after':1,'same_root_failure_limit':2,
                            'stop_threshold_reached':False},
 'previous_round_report_sha256':h(before),'preserved_prefix_bytes':len(before),
 'previous_round_fixed_member':'evidence/review-before.md',
 'previous_round_delivery_unchanged':True,
 'fixed_developer_delivery':{
    'path':'docs/test-reports/artifacts/TASK-20261005-01-r4-delivery.json',
    'sha256':h((A/'TASK-20261005-01-r4-delivery.json').read_bytes()),
    'source_zip_sha256':h((A/'TASK-20261005-01-r4-source.zip').read_bytes()),
    'development_evidence_sha256':h((A/'TASK-20261005-01-r4-evidence.zip').read_bytes()),
    'source_file_count':92},
 'files':[{'path':str(p.relative_to(REPO)), 'sha256':h(p.read_bytes()),'bytes':p.stat().st_size}
          for p in [REPORT,ZIP]],
 'evidence_manifest_sha256':h((E/'archive-manifest.json').read_bytes()),
 'evidence_files':len(manifest['files']),
 'verification':{
    'frontend_tests':43,'frontend_pass':43,'build':'PASS',
    'r3_expected_baseline_failures':2,'r3_baseline_test_count':5,
    'actual_react_pdf_probe':'DEFECT REPRODUCED: created 1, revoked 0, retained readable Blob URL',
    'probe_runtime':'actual React createRoot; deterministic synthetic host, ordinary navigation button click; headless Chromium',
    'production_component_sha256':'afa4fa323f7407668ef404ba1183f4e0000d3ba12ff196f1a81f17b02df4fd78',
    'native_ui':'inspected frozen developer AX/request logs/two real PDF screenshots; checker replay passed; no new native launch',
    'native_heap_measurement':False,'new_financial_requests':0,'reserved_review_job_consumed':False,
    'ledger_sha256':b['ledger_sha256'],'restoration':'PASS','vdoc':vdoc,
    'report_append_only':True,'code_mutation':False,'status_mutation':False,'git_mutation':False,
    'cross_thread_message':False,'new_agents_or_threads':False,'runtime_model':'not independently verified'},
 'final_original_workspace_changes':changed,'final_new_review_artifacts':added
}
INDEX.write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n')
check = json.loads(INDEX.read_text())
for f in check['files']:
    assert h((REPO/f['path']).read_bytes()) == f['sha256'] and (REPO/f['path']).stat().st_size == f['bytes']
print(json.dumps({'result':'PASS','conclusion':idx['conclusion'],'files':idx['files'],
                  'evidence_files':idx['evidence_files'],'round0_prefix_preserved':True,
                  'original_changes':changed,'new_artifacts':added},ensure_ascii=False,indent=2))
