# TASK-20261005-01 第1轮独立复审证据

所审r4清单身份：51a7ed70004a63f2a3e1fab60c4933e507879503892c2b96575139435ceebe7d。
结论：需要修改，M01-R01仍未关闭。43项前端检查和构建通过，不能代替完整URL归属。

`real-react-before-commit.json`是最终普通导航按钮反例；记录生产组件创建1个真实Blob URL、撤销0个，切页后URL仍可读取。实际React createRoot运行于独立无头Chromium；传输及宿主是明确的合成夹具，宿主使用与App一致的导航按钮/setState/条件卸载方式。两次microtask确定性控制窄竞态，无flushSync。未测量原生heap。

重建：从r4源码ZIP解压并核验清单，在新隔离目录沿用项目锁定依赖。把`review-react-entry.tsx`放入隔离`apps/desktop`，改写`build-react-probe.mjs`和`run-real-react-probe.cjs`中的ROOT与已有Vite/Playwright路径，然后分别用Node执行。也可直接使用已保存的`react-probe-bundle.js`，它包含当次实际React及r4组件。全部浏览器外部路由被阻断，传输只返回明确合成内容，真实Blob读回使用标准浏览器fetch。finally释放夹具URL并关闭context/browser。

前端复跑命令：在隔离apps/desktop运行`node --test scripts/evidence_read.test.mjs scripts/index_view.test.cjs scripts/update_recovery.test.cjs scripts/start_daily.test.mjs`和`npm run build`。修复前失败对照需从r3源码ZIP取Legacy组件，配r4的PDF测试；退出1、5项3通过2预期失败，不能误记为r4失败。

`ui-independent-check.json`记录对固定开发原生证据的checker重放、AX/请求时序阅读和两PDF截图查看，原归档SHA在该文件与报告中。不是本评审新启动原生应用。开发UI的“没有迟到视图”无法单独证明Blob URL回收。

`baseline.json`保留开始指纹；原先只计划Node验证，后续为排除调度替身影响增加了有界无头浏览器探针，扩展及恢复记录于verification-summary和restoration。所有任务进程/无头进程归零、六端口与环境/HEAD/索引/共享账本保持；临时依赖引用与构建产物已清理。原报告完整字节保存在`review-before.md`。只有报告追加及本轮审查ZIP/索引写回业务工作区。

本机临时路径不保证永久存在，脚本路径要替换。没有金融来源请求，没有新Agent/聊天/跨窗口消息，未改业务代码、status或Git。证据清单逐项哈希见archive-manifest.json；ZIP及追加后报告的最终哈希在外部review-r1-delivery.json。
