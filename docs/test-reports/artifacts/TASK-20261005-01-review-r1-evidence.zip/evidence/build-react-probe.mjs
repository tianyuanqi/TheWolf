import fs from 'node:fs';
import {build} from '/Users/yuanqi/Documents/ChatGPT/TheWolf/apps/desktop/node_modules/vite/dist/node/index.js';
const app='/private/tmp/thewolf-m01-r4-review-vv_8tefy/workspace/apps/desktop';
const result=await build({root:app,configFile:app+'/vite.config.ts',logLevel:'error',build:{write:false,minify:false,rollupOptions:{input:app+'/review-react-entry.tsx',output:{format:'iife',name:'ReviewProbe'}}}});
for(const output of result.output)if(output.type==='chunk'){fs.writeFileSync('/private/tmp/thewolf-m01-r4-review-vv_8tefy/evidence/react-probe-bundle.js',output.code);console.log('bundle bytes '+output.code.length);}
