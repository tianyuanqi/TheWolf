const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {chromium}=require('/Users/yuanqi/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root='/private/tmp/thewolf-m01-r4-review-vv_8tefy';
(async()=>{let browser,context,page;try{
 browser=await chromium.launch({headless:true});context=await browser.newContext();await context.route('**/*',route=>route.abort());page=await context.newPage();
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.setContent('<!doctype html><html><body><div id="root"></div></body></html>');
 await page.addScriptTag({content:fs.readFileSync(root+'/evidence/react-probe-bundle.js','utf8')});
 await page.getByRole('button',{name:'打开同版本原件'}).waitFor();await page.getByRole('button',{name:'打开同版本原件'}).click();
 await page.waitForFunction(()=>typeof window.finishBody==='function');await page.evaluate(()=>window.finishBody());await page.locator('#market').waitFor();
 const result=await page.evaluate(async()=>({created:window.created,revoked:window.revoked,events:window.reviewEvents,retained_text:await(await window.originalFetch(window.created[0])).text(),iframe_count:document.querySelectorAll('iframe').length}));
 assert.equal(result.created.length,1);assert.equal(result.revoked.length,0);assert.equal(result.retained_text,'explicit synthetic PDF bytes');assert.equal(result.iframe_count,0);assert.deepEqual(errors,[]);
 result.finding='M01-R01';result.result='REPRODUCED';result.runtime='actual React createRoot and ordinary navigation button click in headless Chromium';result.source_sha256=crypto.createHash('sha256').update(fs.readFileSync(root+'/workspace/apps/desktop/src/LegacySliceView.tsx')).digest('hex');result.external_network='all routes aborted; production fetch replaced with explicit synthetic responses';result.page_errors=errors;
 fs.writeFileSync(root+'/evidence/real-react-before-commit.json',JSON.stringify(result,null,2));await page.screenshot({path:root+'/evidence/real-react-after-unmount.png'});console.log(JSON.stringify(result,null,2));
 }finally{if(page){await page.evaluate(()=>window.releaseProbeURLs?.()).catch(()=>{});}if(context)await context.close();if(browser)await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
