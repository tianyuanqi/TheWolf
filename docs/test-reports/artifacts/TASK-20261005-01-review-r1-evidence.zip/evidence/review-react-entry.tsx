import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { LegacySliceView } from './src/LegacySliceView';
const w=window as any;
w.originalFetch=window.fetch.bind(window);w.reviewEvents=[];w.created=[];w.revoked=[];
const create=URL.createObjectURL.bind(URL),revoke=URL.revokeObjectURL.bind(URL);
URL.createObjectURL=(blob)=>{const url=create(blob);w.created.push(url);w.reviewEvents.push('URL created');
  // 先让openEvidence接收URL并排入状态更新，再以同步导航抢先卸载；真实React处理更新优先级。
  queueMicrotask(()=>queueMicrotask(()=>{w.reviewEvents.push('navigation before pending child commit');w.leave();}));return url;};
URL.revokeObjectURL=(url)=>{w.revoked.push(url);w.reviewEvents.push('URL revoked');revoke(url);};
const doc={title:'合成公告',issuer_name:'合成',published_at:null,publication_precision:'unknown',physical_page:1,evidence_text:'合成',source_url:'https://synthetic.invalid',pdf_object_id:'synthetic-pdf'};
const slice={snapshot_id:'synthetic-fixed',instrument_code:'002245',instrument_name:'合成',exchange:'SZSE',source_id:'synthetic',market_contract:{raw_publisher:'synthetic'},calendar_dates:['2026-09-30'],bars:[],open_session_count:1,observed_count:0,unknown_missing_dates:[],complete_through_date:'2026-09-30',documents:[doc]};
w.fetch=async(path:any)=>({ok:true,json:async()=>String(path).endsWith('/update')?{enabled:false,stage:'idle'}:slice,blob:()=>new Promise(resolve=>{w.finishBody=()=>resolve(new Blob(['explicit synthetic PDF bytes'],{type:'application/pdf'}));})});
function Shell(){const[show,setShow]=useState(true);w.leave=()=>document.getElementById('review-nav')!.click();useEffect(()=>{w.reviewEvents.push(show?'legacy committed':'market committed');},[show]);return <><button id='review-nav' onClick={()=>setShow(false)}>市场总览</button>{show?<LegacySliceView sessionToken='synthetic-review'/>:<div id='market'>市场总览（合成测试宿主）</div>}</>;}
createRoot(document.getElementById('root')!).render(<Shell/>);
w.releaseProbeURLs=()=>{for(const url of w.created)revoke(url);};
