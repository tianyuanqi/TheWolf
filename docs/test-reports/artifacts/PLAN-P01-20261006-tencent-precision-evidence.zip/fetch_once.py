"""用户授权的一次腾讯候选取样；固定目标、预算和超时，不修改产品数据。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,signal,requests
from requests.adapters import HTTPAdapter

OUT=Path(__file__).resolve().parent
URL='https://proxy.finance.qq.com/ifzqgtimg/appstock/app/newfqkline/get'
PARAMS={'_var':'kline_dayqfq','param':'sh000300,day,2025-09-04,2026-09-30,640,qfq','r':'0.8205512681390605'}
LIMIT=8*1024*1024

def now():
    return datetime.now(timezone.utc).isoformat()

def expire(signum,frame):
    raise TimeoutError('45秒整体时限')

record={'source':'Tencent','symbol':'sh000300','start_utc':now(),'endpoint':URL,'params':PARAMS,'max_attempts':1,'max_bytes':LIMIT,'redirects':False,'retries':0,'tls_verify':True,'proxy':'inherit_unchanged','bytes':0}
# 排他创建账本，防止中断后误重跑同一请求。
with (OUT/'request-ledger.jsonl').open('x') as ledger:
    ledger.write(json.dumps({'event':'attempt',**record})+'\n');ledger.flush()
    signal.signal(signal.SIGALRM,expire);signal.alarm(45)
    try:
        with requests.Session() as session:
            session.mount('https://',HTTPAdapter(max_retries=0))
            with session.get(URL,params=PARAMS,timeout=(5,15),allow_redirects=False,stream=True,verify=True,headers={'Accept-Encoding':'identity'}) as response:
                record['status_code']=response.status_code
                record['content_type']=response.headers.get('Content-Type')
                response.raise_for_status()
                if response.status_code!=200:raise ValueError('仅接受200，不跟随重定向')
                chunks=[]
                for chunk in response.iter_content(16384):
                    record['bytes']+=len(chunk)
                    if record['bytes']>LIMIT:raise ValueError('正文超过预算')
                    chunks.append(chunk)
                body=b''.join(chunks)
                record['sha256']=hashlib.sha256(body).hexdigest()
                (OUT/'raw-response.bin').write_bytes(body)
                record['result']='saved'
    except Exception as error:
        record['result']='failed';record['error_type']=type(error).__name__
        # 不记录可能携带代理凭据的完整异常串。
    finally:
        signal.alarm(0);record['end_utc']=now()
        ledger.write(json.dumps({'event':'finished',**record})+'\n')
        (OUT/'receipt.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
