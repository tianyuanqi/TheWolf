"""固定原件上的腾讯/中证Decimal对账，禁止网络；不应用舍入容差。"""
from pathlib import Path
from decimal import Decimal
from collections import Counter
import hashlib,json,re,socket
OUT=Path(__file__).resolve().parent
OLD=Path('/private/tmp/thewolf-p01-csi300-qkuqgt8q')
FIELDS=('open','high','low','close')
CSI='40aff181ee6a4503d73cca807ec7c67e7be733429136c59d4e7550b609ca9e43'
CAL='56cfc77e67626ebaa06ae603e265f427784111c95aada0a3577af66adafecf2a'

def deny(*args,**kwargs):raise RuntimeError('离线分析禁止网络')
socket.socket.connect=deny;socket.socket.connect_ex=deny;socket.create_connection=deny

def sha(data):return hashlib.sha256(data).hexdigest()

def analyze():
    body=(OUT/'raw-response.bin').read_bytes();receipt=json.loads((OUT/'receipt.json').read_text())
    assert sha(body)==receipt['sha256']
    match=re.fullmatch(r'kline_dayqfq=(\{.*\});?\s*',body.decode(),flags=re.S);assert match
    doc=json.loads(match[1],parse_float=Decimal);assert doc['code']==0
    data=doc['data']['sh000300'];assert data['qt']['sh000300'][1:3]==['沪深300','000300']
    assert 'day' in data and 'qfqday' not in data
    rows=data['day'];dates=[r[0] for r in rows]
    assert len(dates)==len(set(dates)) and dates==sorted(dates)
    calendar=(OLD/'evidence/calendar.json').read_bytes();assert sha(calendar)==CAL
    days=json.loads(calendar)['expected_W260'];assert len(days)==260 and len(set(days))==260
    cbody=(OLD/'raw'/CSI).read_bytes();assert sha(cbody)==CSI
    cdoc=json.loads(cbody,parse_float=Decimal);assert cdoc['success'] and cdoc['code']=='200'
    assert all(r['indexCode']=='000300' and r['indexNameCn']=='沪深300' for r in cdoc['data'])
    c={r['tradeDate'][:4]+'-'+r['tradeDate'][4:6]+'-'+r['tradeDate'][6:]:{f:Decimal(r[f]) for f in FIELDS} for r in cdoc['data']}
    t={r[0]:dict(zip(('open','close','high','low'),map(Decimal,r[1:5]))) for r in rows if days[0]<=r[0]<=days[-1]}
    missing=sorted(set(days)-set(t));extra=sorted(set(t)-set(days));assert not missing and not extra and set(c)==set(days)
    for source in (c,t):
        for row in source.values():
            assert all(v.is_finite() and v>0 for v in row.values())
            assert row['low']<=row['open']<=row['high'] and row['low']<=row['close']<=row['high']
    audit=[{'date':day,'field':f,'tencent':str(t[day][f]),'csi':str(c[day][f]),'delta':str(t[day][f]-c[day][f])} for day in days for f in FIELDS]
    differences=[r for r in audit if Decimal(r['delta'])!=0]
    beyond=[r for r in audit if Decimal(r['tencent'])%Decimal('.01')!=0]
    result={'source_sha256':receipt['sha256'],'source_bytes':len(body),'csi_sha256':CSI,'calendar_sha256':CAL,'request_count':1,'branch':'day','qfqday_present':False,'request_adjustment_parameter':'qfq (SDK参数；本响应实际只有day)','returned_rows':len(rows),'returned_range':[dates[0],dates[-1]],'window':[days[0],days[-1]],'matched_days':len(t),'missing_days':missing,'unexpected_days_in_window':extra,'excluded_earlier_rows':sum(d<days[0] for d in dates),'excluded_later_rows':sum(d>days[-1] for d in dates),'compared_fields':len(audit),'exact':len(audit)-len(differences),'different':len(differences),'different_days':len({r['date'] for r in differences}),'different_by_field':dict(Counter(r['field'] for r in differences)),'max_abs_delta':str(max(abs(Decimal(r['delta'])) for r in audit)),'nonzero_precision_beyond_2':len(beyond),'valid_ohlc':True,'sorted_unique_dates':True,'opaque_prec_metadata_not_precision':data.get('prec'),'source_version_metadata':data.get('version'),'difference_examples':differences[:12],'boundary_examples':[r for r in audit if r['date'] in (days[0],days[-1])],'rounding_or_tolerance_used':False}
    return result,audit

first,audit=analyze();second,audit2=analyze();assert first==second and audit==audit2
(OUT/'all-field-comparisons.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
first['audit_sha256']=sha((OUT/'all-field-comparisons.json').read_bytes());first['repeat_parse_equal']=True
(OUT/'summary.json').write_text(json.dumps(first,ensure_ascii=False,indent=2));print(json.dumps(first,ensure_ascii=False,indent=2))
