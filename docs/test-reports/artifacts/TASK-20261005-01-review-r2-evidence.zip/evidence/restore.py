from pathlib import Path
import hashlib, json, os, shutil, stat, subprocess

ROOT = Path('/private/tmp/thewolf-m01-r5-review-dlewv9pu')
REPO = Path('/Users/yuanqi/Documents/ChatGPT/TheWolf')
E = ROOT / 'evidence'
h = lambda b: hashlib.sha256(b).hexdigest()
b = json.loads((E / 'baseline.json').read_text())
def run(*args):
    return subprocess.run(args, cwd=REPO, capture_output=True, text=True)

# Only paths created by this isolated review; never follow dependency symlinks.
removed = []
for p in [ROOT/'workspace/apps/desktop/node_modules', ROOT/'r4-reference/apps/desktop/node_modules']:
    if p.exists() or p.is_symlink():
        assert p.is_symlink() and p.resolve() == REPO/'apps/desktop/node_modules'
        p.unlink(); removed.append(str(p.relative_to(ROOT)))
for p in [ROOT/'workspace/apps/desktop/dist', ROOT/'r4-reference']:
    if p.exists():
        assert p.is_dir() and not p.is_symlink()
        shutil.rmtree(p); removed.append(str(p.relative_to(ROOT)))
for p in [ROOT/'workspace/apps/desktop/tsconfig.tsbuildinfo', ROOT/'workspace/apps/desktop/review-react-entry.tsx']:
    if p.exists():
        if p.name == 'review-react-entry.tsx':
            assert p.read_bytes() == (E/'r5'/p.name).read_bytes()
        p.unlink(); removed.append(str(p.relative_to(ROOT)))
for base in [ROOT/'workspace', ROOT/'development-evidence']:
    for p in base.rglob('__pycache__'):
        assert not p.is_symlink()
        shutil.rmtree(p); removed.append(str(p.relative_to(ROOT)))

ps = run('ps', '-axo', 'pid,ppid,command')
assert ps.returncode == 0, 'process inspection unavailable'
listeners = run('lsof', '-nP', '-iTCP', '-sTCP:LISTEN')
processes = [line for line in ps.stdout.splitlines()
             if str(ROOT) in line and any(x in line for x in
                ['uvicorn', '/vite/', 'index_fetch', 'thewolf-desktop', 'run-real-react-probe.cjs'])]
browser_processes = [line for line in ps.stdout.splitlines()
                     if 'playwright_chromiumdev_profile' in line or 'chromium_headless_shell' in line]
ports = {port:any(':'+port+' ' in line for line in listeners.stdout.splitlines()) for port in b['related_ports']}
environment = {k:h(os.environ[k].encode()) if k in os.environ else None for k in b['environment']}
changed = [p for p, sha in b['files'].items() if not (REPO/p).is_file() or h((REPO/p).read_bytes()) != sha]
head = run('git','rev-parse','HEAD').stdout.strip()
index = h(run('git','ls-files','--stage').stdout.encode())
ledger = Path('/private/tmp/thewolf-m01-implementation-3kyht073/evidence/network-ledger.jsonl')
manifest = json.loads((REPO/'docs/test-reports/artifacts/TASK-20261005-01-r5-manifest.json').read_text())
for f in manifest['files']:
    p = ROOT/'workspace'/f['path']
    assert h(p.read_bytes()) == f['sha256'] and p.stat().st_size == f['bytes']
    assert stat.S_IMODE(p.stat().st_mode) == int(f['mode'],8)

result = {
 'result':'PASS', 'removed':removed, 'original_repo_changed_before_report':changed,
 'head_unchanged':head == b['head'], 'index_unchanged':index == b['index_sha256'],
 'environment_hashes_unchanged':environment == b['environment'],
 'ledger_unchanged':h(ledger.read_bytes()) == b['ledger_sha256'],
 'ledger_sha256':h(ledger.read_bytes()), 'related_ports':ports,
 'ports_match_start':ports == b['related_ports'], 'own_running_processes':len(processes),
 'headless_playwright_processes':len(browser_processes),
 'fixed_source_files_verified':len(manifest['files']),
 'blob_teardown':'Probe finally releases created URLs and closes context/browser. No live page remains.',
 'native_application_effects':'none; no native app or its preferences/caches opened or altered',
 'persistent_global_browser_effects':'none; separate ephemeral headless Playwright context, closed in finally',
 'unrestored':[]
}
assert not changed and result['head_unchanged'] and result['index_unchanged']
assert result['environment_hashes_unchanged'] and result['ledger_unchanged']
assert result['ports_match_start'] and not processes and not browser_processes
(E/'restoration.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
