from pathlib import Path
import hashlib, json, re
ROOT = Path('/private/tmp/thewolf-m01-r5-review-dlewv9pu')
E = ROOT/'development-evidence/evidence'
checks = {}
for name, title, page in [('ui-report-read-ax.txt','2026年半年度报告',7),
                          ('ui-forecast-read-ax.txt','2026年半年度业绩预告',1),
                          ('ui-selected-report-ax.txt','2026年半年度报告',7)]:
    text = (E/name).read_text()
    viewers = [line.strip() for line in text.splitlines() if 'URL: blob:' in line]
    assert len(viewers)==1 and f'{title}，第 {page} 页' in viewers[0] and f'#page={page}' in viewers[0]
    assert 'heading 本地归档原件' in text and 'button 关闭' in text
    checks[name] = {'viewer_count':1,'title':title,'page':page,'sha256':hashlib.sha256((E/name).read_bytes()).hexdigest()}
for name in ['ui-report-closed-ax.txt','ui-selection-closed-ax.txt','ui-pdf-away-ax.txt','ui-pdf-reentered-ax.txt']:
    text = (E/name).read_text()
    assert 'URL: blob:' not in text and 'heading 本地归档原件' not in text and 'button 关闭' not in text
    if name=='ui-pdf-away-ax.txt': assert 'heading 沪深300' in text
    if name=='ui-pdf-reentered-ax.txt': assert 'heading 蔚蓝锂芯（002245）日线与公告' in text
    checks[name] = {'viewer_count':0,'sha256':hashlib.sha256((E/name).read_bytes()).hexdigest()}
log = (E/'native.log').read_text()
ids = ['71409583d1d8ce18a49951d2d3079faea8e35a5df8473020f1723a3777eaefdc',
       'd3a5bb349f74f1acb1da17607a877564a969d17eceb39d3d08bedd5bb7d3de51']
for pdf in ids:
    assert re.search(r'GET /api/snapshots/2efb50784685da0d0576e723b64b65d1a7692f73521a979bc8f1ec8e1b076884/pdf/'+pdf+r' HTTP/1.1" 200',log)
assert not re.search(r'"POST ',log)
result = {'result':'PASS','development_evidence_sha256':'f3ace82f8176c77c3a3651a99abbe1c42758f5967ccefd64514c12b0ea1e3262',
 'method':'Independent AX/request-log checks and visual inspection of both real PDF screenshots; no new native app launch.',
 'checks':checks,'fixed_pdf_ids':ids,'post_requests_in_native_log':0,
 'screenshots_viewed':['ui-report.png','ui-forecast.png'],
 'limit':'UI disappearance does not prove resource release. Actual React and standard URL readback establish ownership cleanup separately.',
 'carried_r4_evidence':'Round1 independent check of delayed body navigation, market late evidence, and 120-second uncertain update recovery remains applicable.'}
(ROOT/'evidence/ui-independent-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result':'PASS','ax_files':len(checks),'two_pdf_requests':True,'post_requests':0},ensure_ascii=False))
