import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { build } from '/Users/yuanqi/Documents/ChatGPT/TheWolf/apps/desktop/node_modules/vite/dist/node/index.js';
const require = createRequire(import.meta.url);
const { chromium } = require('/Users/yuanqi/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root = '/private/tmp/thewolf-m01-r5-review-dlewv9pu';
const app = root+'/workspace/apps/desktop';
const bundle = await build({root:app,configFile:app+'/vite.config.ts',logLevel:'error',
  define:{'process.env.NODE_ENV':JSON.stringify('development')},
  build:{write:false,minify:false,rollupOptions:{input:app+'/scripts/pdf_ownership.fixture.tsx',output:{format:'iife',name:'ReviewerEdgeProbe'}}}});
const code = bundle.output.find(item => item.type === 'chunk' && item.isEntry).code;
fs.writeFileSync(root+'/evidence/extra-react-bundle.js',code);
const sourceSha = crypto.createHash('sha256').update(fs.readFileSync(app+'/src/LegacySliceView.tsx')).digest('hex');
const results = [];
for (const kind of ['late-body-after-unmount','close-while-replacement-body-pending']) {
  let browser, context, page;
  try {
    browser = await chromium.launch({headless:true});
    context = await browser.newContext();
    await context.route('**/*',route=>route.abort());
    page = await context.newPage();
    const errors = [];
    page.on('pageerror',error=>errors.push(String(error)));
    await page.setContent('<!doctype html><html><body><div id="root"></div></body></html>');
    await page.evaluate(()=>{window.strictMode=true;});
    await page.addScriptTag({content:code});
    await page.getByRole('button',{name:'打开同版本原件'}).first().waitFor();
    await page.waitForFunction(()=>window.events.filter(event=>event==='legacy committed').length>=2);
    // 正文完成后等待两个实际帧，让异步回调及可提交状态获得处理机会。
    async function finish() {
      await page.evaluate(async()=>{window.finishBody();await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));});
    }
    async function start(index) {
      await page.evaluate(()=>{window.finishBody=undefined;});
      await page.getByRole('button',{name:'打开同版本原件'}).nth(index).click();
      await page.waitForFunction(()=>typeof window.finishBody==='function');
    }
    if (kind==='late-body-after-unmount') {
      await start(0);
      await page.locator('#pdf-probe-nav').click();
      await page.waitForFunction(()=>window.events.includes('market committed'));
      await finish();
    } else {
      await start(0);await finish();await page.locator('iframe').waitFor();
      await start(1);
      await page.getByRole('button',{name:'关闭',exact:true}).click();
      await page.waitForFunction(()=>!document.querySelector('iframe'));
      await finish();
    }
    const result = await page.evaluate(async()=>({created:window.created,revoked:window.revoked,events:window.events,
      readable:await Promise.all(window.created.map(async url=>{try{await(await window.originalFetch(url)).text();return true;}catch{return false;}})),
      iframeCount:document.querySelectorAll('iframe').length}));
    const count = kind==='late-body-after-unmount'?0:1;
    assert.equal(result.created.length,count);
    assert.deepEqual(result.revoked,result.created);
    assert.deepEqual(result.readable,Array(count).fill(false));
    assert.equal(result.iframeCount,0);
    assert.deepEqual(errors,[]);
    results.push({case:kind,result:'PASS',strictMode:true,sourceSha,...result,page_errors:errors});
  } finally {
    if(page) await page.evaluate(()=>window.releaseProbeURLs?.()).catch(()=>{});
    if(context) await context.close();
    if(browser) await browser.close();
  }
}
const out={result:'PASS',tests:2,runtime:'actual development React and headless Chromium; explicit synthetic transport; all external routes aborted',cases:results};
fs.writeFileSync(root+'/evidence/extra-react-edges.json',JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify(out,null,2));
