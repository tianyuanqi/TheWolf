from pathlib import Path
import hashlib,json,os,stat,subprocess,tempfile,zipfile,difflib
REPO=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf');ROOT=Path(tempfile.mkdtemp(prefix='thewolf-m01-r5-review-',dir='/private/tmp'));E=ROOT/'evidence';E.mkdir();A=REPO/'docs/test-reports/artifacts';h=lambda b:hashlib.sha256(b).hexdigest()
def run(*args):return subprocess.run(args,cwd=REPO,capture_output=True,text=True)
files=set(run('git','ls-files').stdout.splitlines())|set(run('git','ls-files','--others','--exclude-standard').stdout.splitlines());ledger=Path('/private/tmp/thewolf-m01-implementation-3kyht073/evidence/network-ledger.jsonl')
ps=run('ps','-axo','pid,ppid,command');listeners=run('lsof','-nP','-iTCP','-sTCP:LISTEN');assert ps.returncode==0
b={'root':str(ROOT),'head':run('git','rev-parse','HEAD').stdout.strip(),'index_sha256':h(run('git','ls-files','--stage').stdout.encode()),'files':{p:h((REPO/p).read_bytes()) for p in sorted(files) if (REPO/p).is_file()},'environment':{k:h(os.environ[k].encode()) if k in os.environ else None for k in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','http_proxy','https_proxy','all_proxy','no_proxy','WOLF_SLICE_DATA_ROOT','WOLF_ENABLE_INDEX_UPDATE','WOLF_ENABLE_DATA_UPDATE','WOLF_PLAYWRIGHT_MODULE','NODE_ENV']},'ledger_sha256':h(ledger.read_bytes()),'related_ports':{port:any(':'+str(port)+' ' in line for line in listeners.stdout.splitlines()) for port in [5173,8000,5174,8001,5184,8014]},'task_processes_before':[line for line in ps.stdout.splitlines() if str(ROOT) in line and any(x in line for x in ['uvicorn','vite','index_fetch','thewolf-desktop'])],'planned_effects':'Isolated Node tests/build plus ephemeral headless Chromium React probes with all external routes blocked; frozen native evidence inspection; no server/native QA/financial requests.'}
(E/'baseline.json').write_text(json.dumps(b,indent=2));(E/'review-before.md').write_bytes((REPO/'docs/test-reports/TASK-20261005-01-review.md').read_bytes())
idx=json.loads((A/'TASK-20261005-01-r5-delivery.json').read_text())
for f in idx['files']:assert h((REPO/f['path']).read_bytes())==f['sha256'] and (REPO/f['path']).stat().st_size==f['bytes'],f['path']
assert h((REPO/'docs/test-reports/TASK-20261005-01-r5-pdf-ownership.md').read_bytes())=='d1ba27d377b106b23e0bbebe995c91371b14a534791cc1e079c4f39d57aa5d44'
assert h((E/'review-before.md').read_bytes())==idx['review_report_sha256']=='1443d018caf82594d49b0edcc0bd1e87f0c310a151007fed11be9821928f4c24'
m=json.loads((A/'TASK-20261005-01-r5-manifest.json').read_text());assert b['head']==m['baseline_git_sha'];assert not m['deleted'] and not m['renames']
with zipfile.ZipFile(A/'TASK-20261005-01-r5-source.zip') as z:
 assert z.testzip() is None;assert set(z.namelist())=={'workspace/'+f['path'] for f in m['files']}|{'manifest.json'};assert z.read('manifest.json')==(A/'TASK-20261005-01-r5-manifest.json').read_bytes()
 for f in m['files']:
  zi=z.getinfo('workspace/'+f['path']);content=z.read(zi);assert h(content)==f['sha256'] and len(content)==f['bytes'] and stat.S_IMODE(zi.external_attr>>16)==int(f['mode'],8),f['path']
  p=ROOT/zi.filename;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(content);p.chmod(int(f['mode'],8))
with zipfile.ZipFile(A/'TASK-20261005-01-r5-evidence.zip') as z:
 assert z.testzip() is None
 for name in z.namelist():assert not name.startswith('/') and '..' not in Path(name).parts
 z.extractall(ROOT/'development-evidence')
with zipfile.ZipFile(A/'TASK-20261005-01-r4-source.zip') as z:
 m3=json.loads(z.read('manifest.json'));assert h(z.read('manifest.json'))=='51a7ed70004a63f2a3e1fab60c4933e507879503892c2b96575139435ceebe7d';old={f['path']:z.read('workspace/'+f['path']) for f in m3['files']}
 for f in m3['files']:assert h(old[f['path']])==f['sha256']
 # 旧回归运行仅需固定组件及清单对照，保持原归档。
 for path in ['apps/desktop/src/LegacySliceView.tsx','apps/desktop/package.json','apps/desktop/vite.config.ts']:
  p=ROOT/'r4-reference'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(old[path])
patch=[];headpatch=[];changed=[];changed_business=[];same=[]
for f in m['files']:
 name=f['path'];before=old.get(name,b'');content=(ROOT/'workspace'/name).read_bytes()
 if before!=content:
  changed.append(name)
  if name.startswith(('apps/','python/')) or name=='README.md':changed_business.append(name)
  patch.extend(difflib.unified_diff(before.decode().splitlines(True),content.decode().splitlines(True),fromfile='r4/'+name if before else '/dev/null',tofile='r5/'+name))
 else:same.append(name)
 if f['role']=='task-implementation' or name=='README.md':
  git=run('git','show',m['baseline_git_sha']+':'+name);base=git.stdout.encode() if git.returncode==0 else b''
  if base!=content:headpatch.extend(difflib.unified_diff(base.decode().splitlines(True),content.decode().splitlines(True),fromfile='HEAD/'+name if base else '/dev/null',tofile='r5/'+name))
assert ''.join(patch).encode()==(A/'TASK-20261005-01-r4-to-r5.patch').read_bytes()
assert ''.join(headpatch).encode()==(A/'TASK-20261005-01-head-to-r5-business.patch').read_bytes()
assert set(changed_business)=={'README.md','apps/desktop/src/LegacySliceView.tsx','apps/desktop/scripts/pdf_ownership.test.mjs','apps/desktop/scripts/pdf_ownership.fixture.tsx'}
result={'result':'PASS','snapshot':idx['snapshot'],'source_files':len(m['files']),'indexed_materials':len(idx['files']),'zip_crc_hash_modes':True,'both_patches_exactly_reconstructed':True,'changed_from_r4':changed,'changed_business':changed_business,'unchanged_business_hashes':[p for p in same if p.startswith(('apps/','python/'))],'review_round0_1_preserved_hash':h((E/'review-before.md').read_bytes())};(E/'material-check.json').write_text(json.dumps(result,indent=2));Path('/private/tmp/thewolf-m01-r5-review-20261006/location.txt').write_text(str(ROOT));print(ROOT);print(json.dumps({k:v for k,v in result.items() if k!='unchanged_business_hashes'},ensure_ascii=False));print('developer evidence entries',len(list((ROOT/'development-evidence').rglob('*'))))
