from pathlib import Path
import hashlib, json, stat, subprocess, zipfile

REPO = Path('/Users/yuanqi/Documents/ChatGPT/TheWolf')
ROOT = Path('/private/tmp/thewolf-m01-r5-review-dlewv9pu')
E = ROOT/'evidence'
A = REPO/'docs/test-reports/artifacts'
REPORT = REPO/'docs/test-reports/TASK-20261005-01-review.md'
ZIP = A/'TASK-20261005-01-review-r2-evidence.zip'
INDEX = A/'TASK-20261005-01-review-r2-delivery.json'
h = lambda b: hashlib.sha256(b).hexdigest()

def package():
    files = [p for p in sorted(E.rglob('*')) if p.is_file() and p.name != 'archive-manifest.json']
    assert not any(p.is_symlink() for p in files)
    manifest = {'task':'TASK-20261005-01','review_round':2,
                'files':[{'path':'evidence/'+str(p.relative_to(E)), 'sha256':h(p.read_bytes()),
                          'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
                         for p in files]}
    (E/'archive-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in files+[E/'archive-manifest.json']:
            z.write(p,'evidence/'+str(p.relative_to(E)))
    with zipfile.ZipFile(ZIP) as z:
        assert z.testzip() is None
        assert set(z.namelist()) == {f['path'] for f in manifest['files']} | {'evidence/archive-manifest.json'}
        for f in manifest['files']:
            content = z.read(f['path'])
            assert h(content)==f['sha256'] and len(content)==f['bytes']
            assert stat.S_IMODE(z.getinfo(f['path']).external_attr>>16)==int(f['mode'],8)
    return manifest

# 文档链接先指向具体存在的材料，检查后写最终哈希，避免循环自引用。
package()
INDEX.write_text(json.dumps({'task':'TASK-20261005-01','review_round':2,'state':'assembling'})+'\n')
subprocess.run(['python3',str(E/'check-review-docs.py')],cwd=REPO,check=True)
manifest = package()
b = json.loads((E/'baseline.json').read_text())
before = (E/'review-before.md').read_bytes()
assert REPORT.read_bytes().startswith(before) and len(before)==25436
assert h(before)=='1443d018caf82594d49b0edcc0bd1e87f0c310a151007fed11be9821928f4c24'
def git(*args):
    return subprocess.run(['git',*args],cwd=REPO,capture_output=True,text=True,check=True).stdout
assert git('rev-parse','HEAD').strip()==b['head']
assert h(git('ls-files','--stage').encode())==b['index_sha256']
changed = [p for p,sha in b['files'].items() if not (REPO/p).is_file() or h((REPO/p).read_bytes())!=sha]
assert changed==['docs/test-reports/TASK-20261005-01-review.md'],changed
current = set(git('ls-files').splitlines()) | set(git('ls-files','--others','--exclude-standard').splitlines())
added = sorted(current-set(b['files']))
assert added==sorted([str(ZIP.relative_to(REPO)),str(INDEX.relative_to(REPO))]),added
restoration = json.loads((E/'restoration.json').read_text())
vdoc = json.loads((E/'vdoc-result.json').read_text())
summary = json.loads((E/'verification-summary.json').read_text())
assert restoration['result']==vdoc['result']==summary['result']=='PASS'
assert h((A/'TASK-20261005-01-r5-source.zip').read_bytes())=='114ff5552671bdfecd4cbd56f968a74c0bf8d94260d34f712a77641c6d8791ed'
for label,expected in [('r4','REPRODUCED'),('r5','PASS')]:
    assert json.loads((E/label/'real-react-before-commit.json').read_text())['result']==expected
idx = {
 'task':'TASK-20261005-01','review_round':2,'review_thread':'01a11071-2602-77f1-a45c-ba32ec471bbc',
 'baseline_sha':b['head'],
 'previous_reviewed_snapshot':'TASK-20261005-01+r4+51a7ed70004a63f2a3e1fab60c4933e507879503892c2b96575139435ceebe7d',
 'fixed_snapshot':'TASK-20261005-01+r5+1592a1fceb7aac187d8602e31f70f27ddcccc4ab1f67c41cc83142c42511eda8',
 'conclusion':'passed','automatic_mode_endpoint':'independent review passed, Git pending submission',
 'findings':[{'id':'M01-R01','classification':'confirmed-defect','severity':'P2','state':'closed',
              'closed_in_snapshot':'r5','evidence':'synchronous ownership; original actual React counterexample now releases URL; original and adjacent consumers remain correct'}],
 'new_findings':[],'reopened_findings':[],'unresolved_task_blockers':[],
 'counters_for_coordinator':{'review_round':2,'review_limit':3,'same_root_failure_before':1,
                            'same_root_failure_after':1,'same_root_failure_limit':2,'counts_reset':False,
                            'stop_threshold_reached':False,'normal_repair_cycle_finished':True},
 'previous_round_report_sha256':h(before),'preserved_prefix_bytes':len(before),
 'previous_round_fixed_member':'evidence/review-before.md','previous_round_deliveries_unchanged':True,
 'fixed_developer_delivery':{
    'path':'docs/test-reports/artifacts/TASK-20261005-01-r5-delivery.json',
    'sha256':h((A/'TASK-20261005-01-r5-delivery.json').read_bytes()),
    'source_zip_sha256':h((A/'TASK-20261005-01-r5-source.zip').read_bytes()),
    'development_evidence_sha256':h((A/'TASK-20261005-01-r5-evidence.zip').read_bytes()),'source_file_count':95},
 'files':[{'path':str(p.relative_to(REPO)),'sha256':h(p.read_bytes()),'bytes':p.stat().st_size} for p in [REPORT,ZIP]],
 'evidence_manifest_sha256':h((E/'archive-manifest.json').read_bytes()),'evidence_files':len(manifest['files']),
 'verification':{
    'frontend_tests':43,'frontend_pass':43,'real_react_new_suite_tests':5,'real_react_new_suite_pass':5,
    'additional_reviewer_react_edge_cases':2,'additional_reviewer_react_pass':2,'build':'PASS',
    'r4_negative_control':'original probe REPRODUCED; 5 new tests 1 pass and 4 expected fail',
    'same_original_entry_rebuilt_for_r5':'PASS: created1 revoked1 unreadable; market committed, iframe0',
    'strictMode_actual_development_replay_verified':True,
    'production_component_sha256':'311a61c1db73493c3ae73e3b82a18c8e157490e73a9b35a8e7c9fb320df2086e',
    'closure_conditions':summary['closure_conditions'],
    'native_ui':'independently checked fixed developer AX/logs/two real PDF screenshots; no new native launch',
    'native_heap_measurement':False,'new_financial_requests':0,'reserved_review_job_consumed':False,
    'ledger_sha256':b['ledger_sha256'],'restoration':'PASS','vdoc':vdoc,
    'report_append_only':True,'code_mutation':False,'status_mutation':False,'git_mutation':False,
    'cross_thread_message':False,'new_agents_or_threads':False,'runtime_model':'not independently verified'},
 'carried_unaffected_evidence':['round0 57 Python tests and loopback/parent EOF','round0 saved real-source 1040 values and legacy compatibility',
                               'round1 delayed body native navigation, market stale evidence, uncertain update recovery'],
 'unexecuted_boundaries':['user acceptance','formal data root operations','distribution','five-year/valuation/PIT','Git submission and publication'],
 'final_original_workspace_changes':changed,'final_new_review_artifacts':added
}
INDEX.write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n')
for f in json.loads(INDEX.read_text())['files']:
    assert h((REPO/f['path']).read_bytes())==f['sha256'] and (REPO/f['path']).stat().st_size==f['bytes']
print(json.dumps({'result':'PASS','conclusion':idx['conclusion'],'closed':'M01-R01','files':idx['files'],
                  'evidence_files':idx['evidence_files'],'round0_1_prefix_preserved':True,
                  'original_changes':changed,'new_artifacts':added},ensure_ascii=False,indent=2))
