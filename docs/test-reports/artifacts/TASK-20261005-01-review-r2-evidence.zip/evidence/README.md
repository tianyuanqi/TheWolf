# TASK-20261005-01 第2轮独立复审证据

所审r5清单身份：1592a1fceb7aac187d8602e31f70f27ddcccc4ab1f67c41cc83142c42511eda8。
结论：通过，M01-R01在r5关闭，Git待提交。复审2/3，同根因失败保持1/2，没有清零。

`r4/`与`r5/`保存从第1轮评审精确entry和脚本独立重建的实际React普通导航探针。两侧均使用普通按钮点击、两次microtask和标准Blob URL，没有flushSync；r4创建1、撤销0、仍可读，r5创建1、撤销1、读回失败。entry除路径放置外保持原文；r5运行端仅调整资源释放预期及失败读回捕获。每侧bundle均重新构建，并非开发者产物。全部外部路由阻断，宿主与传输为明确合成夹具。

重建：解压固定r4/r5源码到各自隔离目录并核对清单，沿用已有锁定依赖。把对应`review-react-entry.tsx`放入各隔离apps/desktop，替换构建/执行脚本中的本机ROOT、app与Vite/Playwright路径，再用Node运行build-react-probe.mjs及run-real-react-probe.cjs。已有bundle也可直接注入独立临时页面，但源码校验仍需正确对应。finally释放夹具URL并关闭浏览器。

新增真实React负对照：把r5的pdf_ownership.fixture.tsx与pdf_ownership.test.mjs配在固定r4生产组件上，设置README规定的既有WOLF_PLAYWRIGHT_MODULE，运行`node --test scripts/pdf_ownership.test.mjs`，5项1通过4预期失败；同一入口对r5为5通过。开发态StrictMode必须实际观察至少两次初始effect提交，不能用生产态StrictMode名称冒称重放。

`extra-react-edges.mjs`导入固定r5的真实React夹具，独立检查两项StrictMode相邻边界：body读取中卸载再完成，不创建URL；已有PDF下读取第二份期间关闭，旧URL释放且第二份迟到不创建URL。精确结果、日志和当次bundle已保存。两项均在夹具最终清理前断言。

43项原专项与构建依README命令复跑，实际输出在v-fe.log和v-build.log。原r4 PDF专项字节不变。没有重复未受影响Python/金融联网/全部原生矩阵。

`ui-independent-check.json`与`check-native-evidence.py`保存对r5固定开发原生AX/请求日志及两真实PDF截图的独立核验；原开发ZIP身份在JSON与报告中。没有另启动原生QA。资源释放由实际React读回与同步归属源码支持，未测量WebKit heap。

`baseline.json`和`restoration.json`记录环境/HEAD/空索引/账本/六端口及恢复。无头浏览器已关闭、任务进程及无头进程均0；隔离构建产物、测试entry、r4临时对照及依赖引用均清理。95份固定源码保持。正式根没有读取或写入。

`review-before.md`是完整第0、1轮报告的25,436字节原文，SHA为1443d018caf82594d49b0edcc0bd1e87f0c310a151007fed11be9821928f4c24。原工作区仅追加审查报告和新增本轮ZIP/索引；未改业务代码、status或Git。临时路径不保证永久存在，重建须替换本机路径。证据逐文件哈希见archive-manifest.json；ZIP及当前报告的最终哈希在外部review-r2-delivery.json。
