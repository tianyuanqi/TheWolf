"""仅指数获取子进程使用无网络替身，服务本身加载原requests包。"""
import sys,os,time,importlib
from pathlib import Path
if "--source" in sys.argv:
    class RequestException(Exception): pass
    def get(*args, **kwargs):
        Path("/private/tmp/thewolf-m01-implementation-3kyht073/evidence/native-fetch-pid.txt").write_text(str(os.getpid()))
        time.sleep(60)
else:
    location=str(Path(__file__).parent)
    sys.path.remove(location)
    del sys.modules[__name__]
    original=importlib.import_module(__name__)
    sys.path.insert(0,location)
    globals().update(original.__dict__)
