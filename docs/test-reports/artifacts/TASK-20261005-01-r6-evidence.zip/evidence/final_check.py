"""只读核对r6固定源码及开始文件保全，不访问正式金融数据。"""
import hashlib,json,stat,subprocess,zipfile
from pathlib import Path
ROOT=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf');E=Path(__file__).parent;A=ROOT/'docs/test-reports/artifacts';h=lambda b:hashlib.sha256(b).hexdigest()
mp=A/'TASK-20261005-01-r6-manifest.json';m=json.loads(mp.read_bytes())
with zipfile.ZipFile(A/'TASK-20261005-01-r6-source.zip') as z:
    assert z.testzip() is None and z.read('manifest.json')==mp.read_bytes()
    assert set(z.namelist())=={'manifest.json'}|{'workspace/'+x['path'] for x in m['files']}
    for x in m['files']:
        info=z.getinfo('workspace/'+x['path']);p=ROOT/x['path']
        assert h(z.read(info))==x['sha256'] and len(z.read(info))==x['bytes'] and stat.S_IMODE(info.external_attr>>16)==int(x['mode'],8)
        assert h(p.read_bytes())==x['sha256'] and stat.S_IMODE(p.stat().st_mode)==int(x['mode'],8),x['path']
b=json.loads((E/'baseline.json').read_bytes());allowed={'README.md','apps/desktop/scripts/start_daily.mjs','apps/desktop/scripts/start_daily.test.mjs'}
for p,v in b['files'].items():
    if p not in allowed:assert h((ROOT/p).read_bytes())==v['sha256'] and stat.S_IMODE((ROOT/p).stat().st_mode)==v['mode'],p
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==b['head']
assert h(subprocess.check_output(['git','diff','--cached','--binary'],cwd=ROOT))==b['index_sha256']
assert h(Path(b['ledger']).read_bytes())==b['ledger_sha256']
r={'result':'PASS','source_files':len(m['files']),'source_hashes_modes_crc':'PASS','manifest_sha256':h(mp.read_bytes()),'workspace_matches_fixed_snapshot':True,'old_reports_artifacts_and_unrelated_files_unchanged':True,'head_index_unchanged':True,'test_ledger_unchanged':True,'formal_data':'not accessed'}
(E/'snapshot-verification.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r))
