"""只读核对r4清单与源码ZIP及所测工作区文件；不连接来源，不修改Git或工作区。"""
import argparse
import hashlib
import json
import stat
import zipfile
from pathlib import Path
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('artifact_directory', type=Path)
args = parser.parse_args()
manifest_path = args.artifact_directory / 'TASK-20261005-01-r6-manifest.json'
manifest = json.loads(manifest_path.read_text())
with zipfile.ZipFile(args.artifact_directory / 'TASK-20261005-01-r6-source.zip') as archive:
    assert archive.testzip() is None
    for item in manifest['files']:
        info = archive.getinfo('workspace/' + item['path'])
        assert hashlib.sha256(archive.read(info)).hexdigest() == item['sha256'], item['path']
        assert stat.S_IMODE(info.external_attr >> 16) == int(item['mode'], 8), item['path']
print(json.dumps({'source_files': len(manifest['files']), 'hashes_modes': 'PASS',
                  'manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest()}))
