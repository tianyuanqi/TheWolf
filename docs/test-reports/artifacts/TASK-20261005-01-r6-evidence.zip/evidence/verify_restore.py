"""仅核验本轮替身测试恢复与原日常进程保持，不访问正式数据或结束已有进程。"""
import hashlib,json,os,socket,stat,subprocess
from pathlib import Path
ROOT=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf');E=Path(__file__).parent;T=E.parent
h=lambda b:hashlib.sha256(b).hexdigest();b=json.loads((E/'baseline.json').read_bytes())
changed=[]
for p,v in b['files'].items():
    f=ROOT/p
    if h(f.read_bytes())!=v['sha256'] or stat.S_IMODE(f.stat().st_mode)!=v['mode']:changed.append(p)
allowed={'README.md','apps/desktop/scripts/start_daily.mjs','apps/desktop/scripts/start_daily.test.mjs'}
assert set(changed)==allowed,changed
ports={}
for port in b['ports']:
    with socket.socket() as s:s.settimeout(.2);ports[port]=s.connect_ex(('127.0.0.1',int(port)))==0
processes={pid:subprocess.check_output(['ps','-p',pid,'-o','command='],text=True).strip() for pid in b['protected_daily_processes']}
assert processes==b['protected_daily_processes']
proxies={k:h(os.environ.get(k,'').encode()) for k in b['proxy_hashes']}
assert proxies==b['proxy_hashes'] and ports==b['ports']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==b['head']
assert h(subprocess.check_output(['git','diff','--cached','--binary'],cwd=ROOT))==b['index_sha256']
assert h(Path(b['ledger']).read_bytes())==b['ledger_sha256']
assert not list((T/'test-tmp').iterdir());(T/'test-tmp').rmdir()
r={'result':'PASS','changed_existing_files':changed,'all_other_baseline_files_and_modes_unchanged':True,'protected_daily_pids':list(processes),'daily_process_commands_unchanged':True,'ports':ports,'ports_match_baseline':True,'proxy_hashes_match':True,'head_index_unchanged':True,'ledger_unchanged':True,'test_npm_stubs_removed':True,'test_tmp_removed':True,'started_real_services_or_apps':False,'formal_data':'not accessed; coordinator owns official data/button checks','retained_daily_window':'existing 5173/8000 intentionally preserved','unrestored_items':[]}
(E/'restoration.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False))
