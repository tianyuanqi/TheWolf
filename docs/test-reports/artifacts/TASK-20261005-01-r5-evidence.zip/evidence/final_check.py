"""只读核对固定r4清单/源码与旧归档；证据包和交付索引在外层最终核对。"""
import hashlib,json,stat,subprocess,zipfile
from pathlib import Path
ROOT=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf');E=Path(__file__).parent;A=ROOT/'docs/test-reports/artifacts'
h=lambda b:hashlib.sha256(b).hexdigest();mp=A/'TASK-20261005-01-r5-manifest.json';m=json.loads(mp.read_bytes())
with zipfile.ZipFile(A/'TASK-20261005-01-r5-source.zip') as z:
    assert z.testzip() is None
    assert z.read('manifest.json')==mp.read_bytes()
    assert set(z.namelist())=={'manifest.json'}|{'workspace/'+x['path'] for x in m['files']}
    for x in m['files']:
        p=x['path'];i=z.getinfo('workspace/'+p)
        assert h(z.read(i))==x['sha256'] and len(z.read(i))==x['bytes'] and stat.S_IMODE(i.external_attr>>16)==int(x['mode'],8),p
        assert h((ROOT/p).read_bytes())==x['sha256'] and stat.S_IMODE((ROOT/p).stat().st_mode)==int(x['mode'],8),p
b=json.loads((E/'baseline.json').read_bytes());allowed={'README.md','apps/desktop/src/LegacySliceView.tsx','docs/status.md'}
for p,v in b['files'].items():
    if p not in allowed:assert h((ROOT/p).read_bytes())==v,p
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==b['head']
assert h(subprocess.check_output(['git','diff','--cached','--binary'],cwd=ROOT))==b['index_sha256']
assert h(Path(b['ledger']).read_bytes())==b['ledger_sha256']
r={'result':'PASS','source_files':len(m['files']),'manifest_sha256':h(mp.read_bytes()),'source_hashes_modes_crc':'PASS','workspace_matches_fixed_snapshot':True,'old_reports_artifacts_and_unrelated_files_unchanged':True,'head_and_index_unchanged':True,'shared_ledger_unchanged':True,'no_deletes_or_renames':True}
(E/'snapshot-verification.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r))
