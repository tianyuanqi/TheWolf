from pathlib import Path
import hashlib,json,re,subprocess,unicodedata
from urllib.parse import unquote
root=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf')
evidence=Path(__file__).parent
targets=['README.md','docs/test-reports/TASK-20261005-01-r5-pdf-ownership.md']
changed_allowed=set(targets)
def anchors(path):
    seen={}; out=set(); fence=False
    for line in path.read_text().splitlines():
        if line.startswith('```'):
            fence=not fence; continue
        if fence: continue
        m=re.match(r'^#{1,6}\s+(.+)',line)
        if not m: continue
        s=m[1].strip().lower().replace('`','')
        s=''.join(c for c in s if c in '_-' or c.isspace() or not unicodedata.category(c).startswith(('P','S'))).replace(' ','-')
        n=seen.get(s,0);seen[s]=n+1
        out.add(s if not n else f'{s}-{n}')
    return out
errors=[]; links=0
for rel in targets:
    path=root/rel; txt=path.read_text(); fenced=False
    for n,line in enumerate(txt.splitlines(),1):
        if line.rstrip()!=line: errors.append(f'{rel}:{n}: trailing whitespace')
        if line.startswith('```'): fenced=not fenced
        if fenced: continue
        for m in re.finditer(r'\[[^\]]*\]\(([^\s)]+)\)',line):
            dest=m[1]
            if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',dest): continue
            links+=1; name,_,frag=unquote(dest).partition('#'); target=(path.parent/name).resolve() if name else path
            if not target.exists(): errors.append(f'{rel}:{n}: missing {dest}')
            elif frag and target.suffix=='.md' and frag not in anchors(target): errors.append(f'{rel}:{n}: missing anchor {dest}')
    if fenced: errors.append(f'{rel}: unclosed fence')
for args in [['git','diff','--check'],['git','diff','--cached','--check']]:
    r=subprocess.run(args,cwd=root,capture_output=True,text=True)
    if r.returncode: errors.append(r.stdout+r.stderr)
result={'result':'PASS' if not errors else 'FAIL','markdown_files':len(targets),'local_links':links,'errors':errors}
(evidence/'vdoc-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(bool(errors))
