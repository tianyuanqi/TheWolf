from pathlib import Path
import hashlib, json, os, stat, subprocess
ROOT = Path('/private/tmp/thewolf-m01-r6-review-42tl1ru3')
REPO = Path('/Users/yuanqi/Documents/ChatGPT/TheWolf')
E = ROOT/'evidence'
h = lambda b: hashlib.sha256(b).hexdigest()
b = json.loads((E/'baseline.json').read_text())
def run(*args):
    return subprocess.run(args,cwd=REPO,capture_output=True,text=True)

# 替身finally清理完成，专用临时根应为空；不操作正式应用或数据根。
tmp = ROOT/'test-tmp'
assert tmp.is_dir() and not list(tmp.iterdir())
tmp.rmdir()
assert not (ROOT/'workspace/.local-data').exists()
ps = run('ps','-axo','pid,ppid,command')
assert ps.returncode==0
owned = [line for line in ps.stdout.splitlines() if str(ROOT) in line
         and any(s in line for s in ['node ', 'npm ', 'uvicorn', '/vite/', 'thewolf-desktop'])]
protected = {}
for port in b['protected_listeners']:
    l = run('lsof','-nP',f'-iTCP:{port}','-sTCP:LISTEN','-Fp')
    pids = sorted({int(line[1:]) for line in l.stdout.splitlines() if line.startswith('p')})
    protected[port] = [{'pid':pid,'identity_sha256':h(run('ps','-p',str(pid),'-o','pid=,ppid=,command=').stdout.strip().encode())} for pid in pids]
environment = {k:h(os.environ[k].encode()) if k in os.environ else None for k in b['environment']}
changed = [p for p,sha in b['files'].items() if not (REPO/p).is_file() or h((REPO/p).read_bytes())!=sha]
head = run('git','rev-parse','HEAD').stdout.strip()
index = h(run('git','ls-files','--stage').stdout.encode())
ledger = Path('/private/tmp/thewolf-m01-implementation-3kyht073/evidence/network-ledger.jsonl')
m = json.loads((REPO/'docs/test-reports/artifacts/TASK-20261005-01-r6-manifest.json').read_text())
for f in m['files']:
    p=ROOT/'workspace'/f['path']
    assert h(p.read_bytes())==f['sha256'] and p.stat().st_size==f['bytes']
    assert stat.S_IMODE(p.stat().st_mode)==int(f['mode'],8)
result = {'result':'PASS','original_files_changed_before_report':changed,'head_unchanged':head==b['head'],
          'index_unchanged':index==b['index_sha256'],'environment_hashes_unchanged':environment==b['environment'],
          'ledger_unchanged':h(ledger.read_bytes())==b['ledger_sha256'],'ledger_sha256':h(ledger.read_bytes()),
          'protected_listeners':protected,'original_port_process_identities_unchanged':protected==b['protected_listeners'],
          'own_remaining_processes':len(owned),'temporary_npm_stub_root_removed':not tmp.exists(),
          'fixed_source_files_verified':len(m['files']),'isolated_data_root_created':False,
          'official_runtime_configuration':'not inspected; no restart or change performed',
          'native_app_or_browser_effects':'none; no app/browser/profile/cache opened or altered',
          'formal_data_access':False,'new_financial_requests':0,'unrestored':[]}
assert not changed and not owned and result['head_unchanged'] and result['index_unchanged']
assert result['environment_hashes_unchanged'] and result['ledger_unchanged']
assert result['original_port_process_identities_unchanged']
(E/'restoration.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
