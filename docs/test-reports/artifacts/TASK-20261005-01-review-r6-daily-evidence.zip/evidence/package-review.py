from pathlib import Path
import hashlib, json, stat, subprocess, zipfile
REPO=Path('/Users/yuanqi/Documents/ChatGPT/TheWolf')
ROOT=Path('/private/tmp/thewolf-m01-r6-review-42tl1ru3')
E=ROOT/'evidence';A=REPO/'docs/test-reports/artifacts'
REPORT=REPO/'docs/test-reports/TASK-20261005-01-review.md'
ZIP=A/'TASK-20261005-01-review-r6-daily-evidence.zip'
INDEX=A/'TASK-20261005-01-review-r6-daily-delivery.json'
h=lambda b:hashlib.sha256(b).hexdigest()
def package():
    files=[p for p in sorted(E.iterdir()) if p.is_file() and p.name!='archive-manifest.json']
    m={'task':'TASK-20261005-01','increment':'r6-daily',
       'files':[{'path':'evidence/'+p.name,'sha256':h(p.read_bytes()),'bytes':p.stat().st_size,
                 'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')} for p in files]}
    (E/'archive-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
    with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in files+[E/'archive-manifest.json']:z.write(p,'evidence/'+p.name)
    with zipfile.ZipFile(ZIP) as z:
        assert z.testzip() is None
        assert set(z.namelist())=={f['path'] for f in m['files']}|{'evidence/archive-manifest.json'}
        for f in m['files']:
            data=z.read(f['path']);assert h(data)==f['sha256'] and len(data)==f['bytes']
            assert stat.S_IMODE(z.getinfo(f['path']).external_attr>>16)==int(f['mode'],8)
    return m

# 本地链接有具体材料后检查文档，再写最终哈希。
package();INDEX.write_text(json.dumps({'task':'TASK-20261005-01','increment':'r6-daily','state':'assembling'})+'\n')
subprocess.run(['python3',str(E/'check-review-docs.py')],cwd=REPO,check=True)
m=package();b=json.loads((E/'baseline.json').read_text());before=(E/'review-before.md').read_bytes()
assert REPORT.read_bytes().startswith(before) and len(before)==37267
assert h(before)=='e2693d847eb06567ef495d0f1da2ca3206aa7fac6f611ac35858e89cac008de2'
def git(*args):return subprocess.run(['git',*args],cwd=REPO,capture_output=True,text=True,check=True).stdout
assert git('rev-parse','HEAD').strip()==b['head'] and h(git('ls-files','--stage').encode())==b['index_sha256']
changed=[p for p,v in b['files'].items() if not (REPO/p).is_file() or h((REPO/p).read_bytes())!=v]
assert changed==['docs/test-reports/TASK-20261005-01-review.md'],changed
current=set(git('ls-files').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
added=sorted(current-set(b['files']))
assert added==sorted([str(ZIP.relative_to(REPO)),str(INDEX.relative_to(REPO))]),added
rest=json.loads((E/'restoration.json').read_text());doc=json.loads((E/'vdoc-result.json').read_text())
assert rest['result']==doc['result']=='PASS'
idx={'task':'TASK-20261005-01','increment':'r6-daily','review_kind':'authorized daily-use incremental code review',
 'review_thread':'01a11071-2602-77f1-a45c-ba32ec471bbc','baseline_sha':b['head'],
 'previous_passed_snapshot':'TASK-20261005-01+r5+1592a1fceb7aac187d8602e31f70f27ddcccc4ab1f67c41cc83142c42511eda8',
 'fixed_snapshot':'TASK-20261005-01+r6+c374f9f225dfd8e18bdba929e37c7c33bdc489ea71d779b093dfaf478a6cdf59',
 'conclusion':'passed for incremental code scope','new_findings':[],'reopened_findings':[],
 'R01':'closed in r5; unchanged','historical_counts':{'repair_reviews':2,'review_limit':3,'same_root_failures':1,'failure_limit':2,'reset':False,'additional_R01_repair_rounds':0},
 'previous_report_sha256':h(before),'preserved_prefix_bytes':len(before),'previous_report_fixed_member':'evidence/review-before.md',
 'fixed_developer_delivery':{'path':'docs/test-reports/artifacts/TASK-20261005-01-r6-delivery.json',
  'sha256':h((A/'TASK-20261005-01-r6-delivery.json').read_bytes()),'source_file_count':96,
  'source_zip_sha256':h((A/'TASK-20261005-01-r6-source.zip').read_bytes()),'development_evidence_sha256':h((A/'TASK-20261005-01-r6-evidence.zip').read_bytes())},
 'files':[{'path':str(p.relative_to(REPO)),'sha256':h(p.read_bytes()),'bytes':p.stat().st_size} for p in [REPORT,ZIP]],
 'evidence_manifest_sha256':h((E/'archive-manifest.json').read_bytes()),'evidence_files':len(m['files']),
 'verification':{'daily_entry_tests':3,'daily_entry_pass':3,'js_syntax_files':2,'js_syntax':'PASS','build':'not rerun, no TS/component/dependency change',
  'fixed_materials_and_both_patches':'PASS','restoration':'PASS','protected_original_listeners':rest['protected_listeners'],
  'official_processes_restarted':False,'official_runtime_flags':'not inspected; pending coordinator restart checks','native_visual_or_interaction_check':'not performed',
  'formal_financial_data_access':False,'financial_requests':0,'reserved_review_job_consumed':False,'ledger_sha256':b['ledger_sha256'],
  'code_mutation':False,'status_mutation':False,'git_mutation':False,'cross_thread_message':False,'new_agents_or_threads':False,'runtime_model':'not independently verified','vdoc':doc},
 'pending_after_code_review':['coordinator restart/read-only runtime and pre-click data preservation checks','user first actual update click and native experience acceptance'],
 'final_original_workspace_changes':changed,'new_review_artifacts':added}
INDEX.write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n')
for f in json.loads(INDEX.read_text())['files']:
    assert h((REPO/f['path']).read_bytes())==f['sha256'] and (REPO/f['path']).stat().st_size==f['bytes']
print(json.dumps({'result':'PASS','conclusion':idx['conclusion'],'files':idx['files'],'evidence_files':idx['evidence_files'],
 'original_report_prefix_preserved':True,'changes':changed,'new_artifacts':added},ensure_ascii=False,indent=2))
