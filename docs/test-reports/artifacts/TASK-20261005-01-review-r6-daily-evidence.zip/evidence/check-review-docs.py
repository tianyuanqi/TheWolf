from pathlib import Path
import json, re, subprocess
from urllib.parse import unquote

REPO = Path('/Users/yuanqi/Documents/ChatGPT/TheWolf')
ROOT = Path('/private/tmp/thewolf-m01-r6-review-42tl1ru3')
p = REPO/'docs/test-reports/TASK-20261005-01-review.md'
text = p.read_text()
errors, links = [], []
for target in re.findall(r'(?<!!)\[[^\]]+\]\(([^)]+)\)', text):
    if re.match(r'^[a-z]+:', target):
        continue
    location, _, anchor = unquote(target).partition('#')
    dest = (p.parent/location).resolve() if location else p
    if not dest.exists():
        errors.append('missing '+target)
    elif anchor:
        headings = re.findall(r'^#{1,6}\s+(.+)$', dest.read_text(), re.M)
        slug = lambda s: re.sub(r'[^\w\-\s]', '', s.lower()).replace(' ', '-')
        if anchor not in map(slug, headings):
            errors.append('missing anchor '+target)
    links.append(target)
if sum(line.startswith('```') for line in text.splitlines()) % 2:
    errors.append('unbalanced fences')
if any(line.rstrip() != line for line in text.splitlines()):
    errors.append('trailing whitespace')
for command in (['git','diff','--check'], ['git','diff','--cached','--check']):
    result = subprocess.run(command, cwd=REPO, capture_output=True, text=True)
    if result.returncode:
        errors.append(result.stdout+result.stderr)
before = (ROOT/'evidence/review-before.md').read_bytes()
if not p.read_bytes().startswith(before):
    errors.append('round0 prefix altered')
if p.read_bytes().count('## 6. 第1轮独立复审'.encode()) != 1:
    errors.append('round1 historical appendix missing or duplicated')
if p.read_bytes().count('## 7. 第2轮独立复审'.encode()) != 1:
    errors.append('round2 historical appendix missing or duplicated')
if p.read_bytes().count('## 8. r6日常使用衔接增量审查'.encode()) != 1:
    errors.append('r6 incremental appendix missing or duplicated')
r = {'result':'PASS' if not errors else 'FAIL', 'markdown_files':1,
     'local_links':len(links), 'preserved_round0_1_2_bytes':len(before), 'errors':errors}
(ROOT/'evidence/vdoc-result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(r,ensure_ascii=False))
assert not errors
