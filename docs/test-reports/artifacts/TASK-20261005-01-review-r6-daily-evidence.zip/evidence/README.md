# TASK-20261005-01 r6日常使用衔接独立增量审查

固定r6：c374f9f225dfd8e18bdba929e37c7c33bdc489ea71d779b093dfaf478a6cdf59。增量代码审查通过；当前正式进程的新配置、原生按钮及首次用户点击未验证，不代表验收通过。M01-R01保持r5关闭，原修复复审2/3及失败1/2保持，本次不是第3轮R01修复。

prepare.py独立核验6份交付材料、96文件哈希/模式/ZIP CRC，并重建r5→r6和HEAD累计业务patch。测试只使用隔离源码和临时npm替身，完全没有执行真实npm/Tauri、访问正式数据或请求金融来源。

在新的独立TMPDIR运行`node --test scripts/start_daily.test.mjs`，3项全通过；两份`node --check`结果在static-check.json。替身断言父环境指数0被1覆盖、固定正式根/端口/Cargo目标、仅run tauri -- dev参数以及退出23/SIGTERM保持。没有增加其他业务测试或重跑构建。

baseline.json保存代理/环境与原工作区摘要、HEAD/索引及现有正式监听者PID/命令摘要；restoration.json证明PID14561/14640及端口身份保持、其他四端口无监听、临时替身全部清理、无本轮进程残留、共享账本保持。没有启动或操作原生应用/浏览器，所以无本轮窗口/缓存/配置影响。当前正式应用内部配置未读取。

review-before.md是完整第0、1、2轮报告37,267字节，SHA e2693d847eb06567ef495d0f1da2ca3206aa7fac6f611ac35858e89cac008de2。只追加报告§8及新增本轮审查ZIP/索引；业务代码、status、Git和旧材料保持。最终哈希由外部review-r6-daily-delivery.json固定；ZIP内清单逐项核验。

临时路径不保证永久存在。重建只需固定r6导出、Node和一个空的TMPDIR，不需正式金融输入或依赖安装；按该次实际环境重新记录进程/端口基线。协调者随后重启其日常窗口并只读核对运行配置，用户亲自首次点击更新和验收。
